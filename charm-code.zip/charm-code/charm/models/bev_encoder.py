"""BEV encoder: one strided stage and one full-resolution stage, producing the C x H x W BEV feature."""

import torch.nn as nn

from .common import ResBlock


class BEVEncoder(nn.Module):
    def __init__(self, in_channels, out_channels=64):
        super().__init__()
        self.stage1 = nn.Sequential(ResBlock(in_channels, out_channels, stride=2), ResBlock(out_channels, out_channels))
        self.stage2 = nn.Sequential(ResBlock(out_channels, out_channels), ResBlock(out_channels, out_channels))

    def forward(self, x):
        return self.stage2(self.stage1(x))
