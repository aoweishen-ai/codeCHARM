"""Centre-based BEV detection head with Gaussian focal loss and smooth L1 box regression."""

import math

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

from ..utils.box_ops import nms_bev
from .common import ConvNormAct


def gaussian_radius(height, width, min_overlap=0.1):
    a1, b1 = 1.0, height + width
    c1 = width * height * (1 - min_overlap) / (1 + min_overlap)
    r1 = (b1 + math.sqrt(max(b1 ** 2 - 4 * a1 * c1, 0.0))) / 2
    a2, b2 = 4.0, 2 * (height + width)
    c2 = (1 - min_overlap) * width * height
    r2 = (b2 + math.sqrt(max(b2 ** 2 - 4 * a2 * c2, 0.0))) / 2
    a3, b3 = 4 * min_overlap, -2 * min_overlap * (height + width)
    c3 = (min_overlap - 1) * width * height
    r3 = (b3 + math.sqrt(max(b3 ** 2 - 4 * a3 * c3, 0.0))) / 2
    return min(r1, r2, r3)


def draw_gaussian(heatmap, center, radius):
    diameter = 2 * radius + 1
    sigma = diameter / 6.0
    m = np.arange(-radius, radius + 1)
    gaussian = np.exp(-(m[:, None] ** 2 + m[None, :] ** 2) / (2 * sigma * sigma))
    x, y = center
    H, W = heatmap.shape
    left, right = min(x, radius), min(W - x, radius + 1)
    top, bottom = min(y, radius), min(H - y, radius + 1)
    region = heatmap[y - top:y + bottom, x - left:x + right]
    patch = gaussian[radius - top:radius + bottom, radius - left:radius + right]
    if region.size and patch.size:
        np.maximum(region, patch, out=region)


def gaussian_focal_loss(logits, target, alpha=2.0, beta=4.0):
    pred = torch.sigmoid(logits.float()).clamp(1e-4, 1 - 1e-4)
    pos = target.eq(1).float()
    neg = 1.0 - pos
    pos_loss = torch.log(pred) * (1 - pred) ** alpha * pos
    neg_loss = torch.log(1 - pred) * pred ** alpha * (1 - target) ** beta * neg
    num_pos = pos.sum().clamp(min=1.0)
    return -(pos_loss.sum() + neg_loss.sum()) / num_pos


class CenterHead(nn.Module):
    def __init__(self, in_channels, grid, num_classes=1, head_channels=64, reg_weight=0.25,
                 min_radius=2, min_overlap=0.1, max_objs=256):
        super().__init__()
        self.grid = grid
        self.num_classes = num_classes
        self.reg_weight = reg_weight
        self.min_radius = min_radius
        self.min_overlap = min_overlap
        self.max_objs = max_objs
        self.shared = ConvNormAct(in_channels, head_channels, 3)

        def branch(out_ch, bias=0.0):
            seq = nn.Sequential(
                nn.Conv2d(head_channels, head_channels, 3, padding=1), nn.ReLU(inplace=True),
                nn.Conv2d(head_channels, out_ch, 1),
            )
            nn.init.constant_(seq[-1].bias, bias)
            return seq

        self.heatmap = branch(num_classes, -2.19)
        self.reg = branch(2)
        self.height = branch(1)
        self.dim = branch(3)
        self.rot = branch(2)

    def forward(self, x):
        f = self.shared(x)
        return {
            "heatmap": self.heatmap(f),
            "reg": self.reg(f),
            "height": self.height(f),
            "dim": self.dim(f),
            "rot": self.rot(f),
        }

    def confidence(self, x):
        """Spatial confidence map used as the sender-side value cue: (N, 1, H, W)."""
        return torch.sigmoid(self.heatmap(self.shared(x)).float()).amax(dim=1, keepdim=True)

    @torch.no_grad()
    def build_targets(self, gt_boxes, gt_mask, gt_cls=None):
        g = self.grid
        B, M = gt_boxes.shape[:2]
        heat = np.zeros((B, self.num_classes, g.H, g.W), np.float32)
        ind = np.zeros((B, self.max_objs), np.int64)
        mask = np.zeros((B, self.max_objs), np.float32)
        reg = np.zeros((B, self.max_objs, 8), np.float32)
        boxes = gt_boxes.detach().float().cpu().numpy()
        valid = gt_mask.detach().cpu().numpy().astype(bool)
        cls = gt_cls.detach().cpu().numpy() if gt_cls is not None else np.zeros((B, M), np.int64)
        for b in range(B):
            k = 0
            for m in range(M):
                if not valid[b, m] or k >= self.max_objs:
                    continue
                x, y, z, l, w, h, yaw = boxes[b, m, :7]
                fx = (x - g.x_min) / g.res
                fy = (y - g.y_min) / g.res
                cx, cy = int(math.floor(fx)), int(math.floor(fy))
                if not (0 <= cx < g.W and 0 <= cy < g.H):
                    continue
                radius = max(self.min_radius, int(gaussian_radius(l / g.res, w / g.res, self.min_overlap)))
                c = int(min(max(cls[b, m], 0), self.num_classes - 1))
                draw_gaussian(heat[b, c], (cx, cy), radius)
                ind[b, k] = cy * g.W + cx
                mask[b, k] = 1.0
                reg[b, k] = [fx - cx, fy - cy, z, math.log(max(l, 1e-3)), math.log(max(w, 1e-3)),
                             math.log(max(h, 1e-3)), math.sin(yaw), math.cos(yaw)]
                k += 1
        device = gt_boxes.device
        return {
            "heatmap": torch.from_numpy(heat).to(device),
            "ind": torch.from_numpy(ind).to(device),
            "mask": torch.from_numpy(mask).to(device),
            "reg": torch.from_numpy(reg).to(device),
        }

    def loss(self, preds, targets):
        hm = gaussian_focal_loss(preds["heatmap"], targets["heatmap"])
        dense = torch.cat([preds["reg"], preds["height"], preds["dim"], preds["rot"]], dim=1).float()
        B, C = dense.shape[:2]
        ind = targets["ind"][:, None, :].expand(B, C, -1)
        pred = dense.view(B, C, -1).gather(2, ind).permute(0, 2, 1)
        mask = targets["mask"][..., None]
        reg = F.smooth_l1_loss(pred * mask, targets["reg"] * mask, reduction="sum")
        reg = reg / mask.sum().clamp(min=1.0)
        return hm + self.reg_weight * reg

    @torch.no_grad()
    def decode(self, preds, score_threshold=0.05, nms_iou=0.15, max_det=100):
        g = self.grid
        heat = torch.sigmoid(preds["heatmap"].float())
        B, nc, H, W = heat.shape
        peaks = F.max_pool2d(heat, 3, stride=1, padding=1)
        heat = heat * (peaks == heat).float()
        scores, inds = heat.view(B, -1).topk(min(max_det * 2, heat[0].numel()))
        pix = inds % (H * W)
        ys = (pix // W).float()
        xs = (pix % W).float()

        def gather(t):
            t = t.float().view(B, t.shape[1], -1)
            return t.gather(2, pix[:, None, :].expand(B, t.shape[1], pix.shape[1]))

        reg, height, dim, rot = gather(preds["reg"]), gather(preds["height"]), gather(preds["dim"]), gather(preds["rot"])
        x = g.x_min + (xs + reg[:, 0]) * g.res
        y = g.y_min + (ys + reg[:, 1]) * g.res
        z = height[:, 0]
        lwh = torch.exp(dim.clamp(max=5.0))
        yaw = torch.atan2(rot[:, 0], rot[:, 1])
        boxes = torch.stack([x, y, z, lwh[:, 0], lwh[:, 1], lwh[:, 2], yaw], dim=-1)
        results = []
        for b in range(B):
            keep = scores[b] > score_threshold
            bx = boxes[b][keep].cpu().numpy()
            sc = scores[b][keep].cpu().numpy()
            if len(bx):
                k = nms_bev(bx, sc, nms_iou)[:max_det]
                bx, sc = bx[k], sc[k]
            results.append({"boxes": bx.astype(np.float32), "scores": sc.astype(np.float32)})
        return results
