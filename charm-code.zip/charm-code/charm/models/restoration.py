"""Restoration modules for lost token groups. All share the interface

    loss(u0, u_known, mask, region, u_ego, z_c) -> (loss, x0_hat or None, weight or None)
    restore(u_known, mask, u_ego, z_c)         -> (completed latent, per-cell dispersion)
"""

import torch
import torch.nn as nn

from .diffusion import InpaintUNet, LatentDiffusionInpainter


class ZeroRestorer(nn.Module):
    """Lost regions stay zero."""

    def loss(self, u0, u_known, mask, region, u_ego, z_c):
        return u0.sum() * 0.0, None, None

    @torch.no_grad()
    def restore(self, u_known, mask, u_ego, z_c, num_samples=None):
        N, _, H, W = u_known.shape
        return u_known * mask, u_known.new_zeros(N, 1, H, W)


class RegressionRestorer(nn.Module):
    """Deterministic U-Net regressor trained with an L1 loss on the lost region."""

    def __init__(self, cfg, latent_channels, cond_dim):
        super().__init__()
        self.use_ego = bool(cfg.get("ego_conditioning", True))
        self.net = InpaintUNet(
            latent_channels=latent_channels, cond_dim=cond_dim,
            base=int(cfg.get("base_channels", 64)), mults=tuple(cfg.get("channel_mults", [1, 2, 2])),
        )

    def _predict(self, u_known, mask, u_ego, z_c):
        t = torch.zeros(u_known.shape[0], device=u_known.device, dtype=torch.long)
        ue = u_ego if self.use_ego else torch.zeros_like(u_ego)
        out = self.net(u_known * mask, t, mask, ue, z_c).float()
        return mask * u_known + (1 - mask) * out

    def loss(self, u0, u_known, mask, region, u_ego, z_c):
        if u0.shape[0] == 0:
            return u0.sum() * 0.0, None, None
        pred = self._predict(u_known, mask, u_ego, z_c)
        w = (1 - mask) * region
        loss = (w * (pred - u0).abs()).sum() / (w.sum() * u0.shape[1]).clamp_min(1.0)
        return loss, pred, torch.ones(u0.shape[0], device=u0.device)

    @torch.no_grad()
    def restore(self, u_known, mask, u_ego, z_c, num_samples=None):
        N, _, H, W = u_known.shape
        return self._predict(u_known, mask, u_ego, z_c), u_known.new_zeros(N, 1, H, W)


def build_restorer(cfg, latent_channels, cond_dim):
    kind = cfg.get("type", "diffusion")
    if kind == "diffusion":
        return LatentDiffusionInpainter(cfg, latent_channels, cond_dim)
    if kind == "regressor":
        return RegressionRestorer(cfg, latent_channels, cond_dim)
    if kind == "zero":
        return ZeroRestorer()
    raise ValueError(f"unknown restorer type: {kind}")
