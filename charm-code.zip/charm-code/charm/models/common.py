"""Shared neural building blocks."""

import math

import torch
import torch.nn as nn
import torch.nn.functional as F


def group_norm(channels, max_groups=8):
    groups = max_groups
    while channels % groups != 0:
        groups //= 2
    return nn.GroupNorm(max(groups, 1), channels)


class ConvNormAct(nn.Sequential):
    def __init__(self, cin, cout, kernel=3, stride=1):
        super().__init__(
            nn.Conv2d(cin, cout, kernel, stride=stride, padding=kernel // 2, bias=False),
            group_norm(cout),
            nn.SiLU(inplace=True),
        )


class ResBlock(nn.Module):
    def __init__(self, cin, cout, stride=1):
        super().__init__()
        self.conv1 = nn.Conv2d(cin, cout, 3, stride=stride, padding=1, bias=False)
        self.norm1 = group_norm(cout)
        self.conv2 = nn.Conv2d(cout, cout, 3, padding=1, bias=False)
        self.norm2 = group_norm(cout)
        self.skip = (
            nn.Identity() if (cin == cout and stride == 1)
            else nn.Sequential(nn.Conv2d(cin, cout, 1, stride=stride, bias=False), group_norm(cout))
        )

    def forward(self, x):
        h = F.silu(self.norm1(self.conv1(x)))
        h = self.norm2(self.conv2(h))
        return F.silu(h + self.skip(x))


class FiLM(nn.Module):
    """Feature-wise affine modulation from a conditioning vector, initialised to the identity."""

    def __init__(self, cond_dim, channels):
        super().__init__()
        self.proj = nn.Linear(cond_dim, 2 * channels)
        nn.init.zeros_(self.proj.weight)
        nn.init.zeros_(self.proj.bias)

    def forward(self, x, cond, channel_last=False):
        gamma, beta = self.proj(cond).chunk(2, dim=-1)
        if channel_last:
            shape = (cond.shape[0],) + (1,) * (x.dim() - 2) + (-1,)
        else:
            shape = (cond.shape[0], -1) + (1,) * (x.dim() - 2)
        return x * (1.0 + gamma.view(shape).to(x.dtype)) + beta.view(shape).to(x.dtype)


class TimeEncoding(nn.Module):
    """Sinusoidal encoding of a continuous time value in seconds."""

    def __init__(self, dim, num_freqs=8, min_period=0.025, max_period=4.0):
        super().__init__()
        freqs = torch.exp(torch.linspace(math.log(1.0 / max_period), math.log(1.0 / min_period), num_freqs))
        self.register_buffer("freqs", 2.0 * math.pi * freqs)
        self.proj = nn.Linear(2 * num_freqs, dim)

    def forward(self, t):
        angles = t.float()[..., None] * self.freqs
        return self.proj(torch.cat([torch.sin(angles), torch.cos(angles)], dim=-1))


def inverse_softplus(x):
    return x + torch.log(-torch.expm1(-x))
