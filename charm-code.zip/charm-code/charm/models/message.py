"""Sender side: token-group value estimation, channel-conditioned knapsack selection and quantisation."""

import math

import torch
import torch.nn as nn
import torch.nn.functional as F


def group_view(x, s):
    """(N, C, H, W) -> (N, G, C, s, s) with G = (H/s) * (W/s) in row-major group order."""
    N, C, H, W = x.shape
    gh, gw = H // s, W // s
    x = x.view(N, C, gh, s, gw, s).permute(0, 2, 4, 1, 3, 5)
    return x.reshape(N, gh * gw, C, s, s)


def groups_to_cells(values, s, gh, gw):
    """Broadcast per-group values (N, G) or (N, G, L) to cells: (N, 1, H, W) or (N, L, H, W)."""
    squeeze = values.dim() == 2
    if squeeze:
        values = values[..., None]
    N, G, L = values.shape
    v = values.view(N, gh, gw, L).permute(0, 3, 1, 2)
    v = v.repeat_interleave(s, dim=2).repeat_interleave(s, dim=3)
    return v


def quantize_groups(u, s, bits):
    """Uniform per-group min/max quantisation with a straight-through gradient."""
    N, C, H, W = u.shape
    x = u.view(N, C, H // s, s, W // s, s)
    lo = x.amin(dim=(1, 3, 5), keepdim=True)
    hi = x.amax(dim=(1, 3, 5), keepdim=True)
    scale = (hi - lo).clamp_min(1e-6)
    levels = float(2 ** bits - 1)
    q = torch.round((x - lo) / scale * levels) / levels * scale + lo
    q = x + (q - x).detach()
    return q.view(N, C, H, W)


def binary_entropy(p, eps=1e-6):
    p = p.clamp(eps, 1 - eps)
    return -(p * torch.log(p) + (1 - p) * torch.log(1 - p)) / math.log(2.0)


class TokenValueHead(nn.Module):
    """Per-group value at every quantisation level; values are non-decreasing in bit depth."""

    def __init__(self, cond_dim, hidden=64, num_levels=3):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(2 + cond_dim, hidden), nn.SiLU(),
            nn.Linear(hidden, hidden), nn.SiLU(),
            nn.Linear(hidden, num_levels),
        )

    def forward(self, conf, ent, z_c):
        G = conf.shape[1]
        x = torch.cat([conf[..., None], ent[..., None], z_c[:, None, :].expand(-1, G, -1)], dim=-1)
        raw = self.net(x.float())
        increments = torch.cat([raw[..., :1], F.softplus(raw[..., 1:])], dim=-1)
        return increments.cumsum(dim=-1)


class MessageBuilder(nn.Module):
    """Builds the sparse, quantised token message under a per-link byte budget.

    Each token group can be skipped or sent at one of several bit depths. The multiple-choice
    knapsack is relaxed with a Lagrange multiplier found by bisection and a softmax at temperature
    eta; a hard, budget-feasible decision is used in the forward pass with a straight-through
    gradient to the value head.
    """

    def __init__(self, cfg, latent_channels, cond_dim, group_size):
        super().__init__()
        self.s = int(group_size)
        self.levels = [int(b) for b in cfg.get("bit_levels", [2, 4, 8])]
        self.eta = float(cfg.get("temperature", 0.5))
        self.iters = int(cfg.get("bisection_iters", 25))
        self.mode = cfg.get("gate", "knapsack")
        header = float(cfg.get("header_bytes", 18))
        cells = self.s * self.s * latent_channels
        costs = torch.tensor([header + cells * q / 8.0 for q in self.levels], dtype=torch.float32)
        self.register_buffer("costs", costs, persistent=False)
        self.value_head = TokenValueHead(cond_dim, num_levels=len(self.levels))

    def group_cues(self, conf):
        g = group_view(conf.float(), self.s)  # (N, G, 1, s, s)
        return g.flatten(2).amax(-1), binary_entropy(g.flatten(2)).mean(-1)

    def _probs(self, values, lam):
        cost_kb = self.costs / 1024.0
        util = (values - lam[:, None, None] * cost_kb) / self.eta
        logits = torch.cat([torch.zeros_like(util[..., :1]), util], dim=-1)
        return logits.softmax(dim=-1)

    @torch.no_grad()
    def _solve_multiplier(self, values, budget):
        N = values.shape[0]
        finite = torch.isfinite(budget)
        cost_kb = self.costs / 1024.0
        vmax = values.amax(dim=(1, 2)).clamp_min(0.0)
        hi = (vmax + 30.0 * self.eta) / cost_kb.min()
        lo = torch.zeros(N, device=values.device)
        target = torch.where(finite, budget, torch.full_like(budget, float("inf")))
        for _ in range(self.iters):
            mid = 0.5 * (lo + hi)
            expected = (self._probs(values, mid)[..., 1:] * self.costs).sum(dim=(1, 2))
            over = expected > target
            lo = torch.where(over, mid, lo)
            hi = torch.where(over, hi, mid)
        return torch.where(finite, hi, torch.zeros_like(hi))

    @torch.no_grad()
    def _enforce_budget(self, choice, values, lam, budget):
        """Greedy repair so that the hard selection never exceeds the scheduler budget."""
        cost_all = torch.cat([self.costs.new_zeros(1), self.costs])
        cost = cost_all[choice]
        util_all = torch.cat(
            [torch.zeros_like(values[..., :1]), values - lam[:, None, None] * (self.costs / 1024.0)], dim=-1
        )
        util = util_all.gather(-1, choice[..., None]).squeeze(-1)
        order = util.argsort(dim=1, descending=True)
        cum = cost.gather(1, order).cumsum(dim=1)
        keep_sorted = cum <= budget[:, None]
        keep = torch.zeros_like(keep_sorted).scatter(1, order, keep_sorted)
        return torch.where(keep, choice, torch.zeros_like(choice))

    def _topk_choice(self, conf_g, budget):
        """Fixed top-k by confidence at the highest bit depth, k chosen to fill the budget."""
        N, G = conf_g.shape
        top_cost = self.costs[-1]
        k = torch.where(torch.isfinite(budget), torch.floor(budget / top_cost), torch.full_like(budget, G))
        k = k.clamp(0, G).long()
        order = conf_g.argsort(dim=1, descending=True)
        rank = torch.empty_like(order).scatter_(1, order, torch.arange(G, device=conf_g.device).expand(N, G))
        return torch.where(rank < k[:, None], torch.full_like(rank, len(self.levels)), torch.zeros_like(rank))

    def forward(self, u, conf, z_c, budget):
        N, C, H, W = u.shape
        gh, gw = H // self.s, W // self.s
        L = len(self.levels)
        conf_g, ent_g = self.group_cues(conf)
        values = self.value_head(conf_g, ent_g, z_c)  # (N, G, L)
        budget = budget.float()

        if self.mode == "topk":
            choice = self._topk_choice(conf_g, budget)
            soft = F.one_hot(choice, L + 1).float()
        elif self.mode == "all":
            choice = torch.full(conf_g.shape, L, dtype=torch.long, device=u.device)
            soft = F.one_hot(choice, L + 1).float()
        else:
            lam = self._solve_multiplier(values.detach(), budget)
            soft = self._probs(values, lam)
            choice = soft.detach().argmax(dim=-1)
            choice = self._enforce_budget(choice, values.detach(), lam, budget)

        hard = F.one_hot(choice, L + 1).float()
        st = hard + soft - soft.detach()

        quantised = torch.stack([quantize_groups(u, self.s, q) for q in self.levels], dim=1)  # (N, L, C, H, W)
        weights = groups_to_cells(st[..., 1:], self.s, gh, gw)  # (N, L, H, W)
        u_sent = (weights[:, :, None] * quantised).sum(dim=1)

        sent = choice > 0
        bytes_hard = (hard[..., 1:] * self.costs).sum(dim=(1, 2))
        bytes_expected = (soft[..., 1:] * self.costs).sum(dim=(1, 2))
        return {
            "u": u_sent,
            "sent": sent,
            "level": choice,
            "bytes": bytes_hard,
            "exp_bytes": bytes_expected,
            "values": values,
        }
