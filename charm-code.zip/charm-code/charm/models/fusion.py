"""Reliability head and reliability-biased cross-agent attention fusion."""

import torch
import torch.nn as nn
import torch.nn.functional as F

from .common import ConvNormAct


class ReliabilityHead(nn.Module):
    """Per-token reliability from the channel embedding, restoration dispersion, warp validity,
    residual horizon and whether the token was synthesised."""

    def __init__(self, cond_dim, hidden=64, tau_scale=0.5):
        super().__init__()
        self.tau_scale = float(tau_scale)
        self.net = nn.Sequential(
            nn.Conv2d(cond_dim + 4, hidden, 1), nn.SiLU(),
            nn.Conv2d(hidden, hidden, 1), nn.SiLU(),
            nn.Conv2d(hidden, 1, 1),
        )

    def forward(self, z_c, dispersion, omega, horizon, synthesised):
        N, _, H, W = dispersion.shape
        zc = z_c.float()[:, :, None, None].expand(-1, -1, H, W)
        d = (horizon.float() / self.tau_scale)[:, None, None, None].expand(-1, 1, H, W)
        x = torch.cat([zc, torch.log1p(dispersion.float()), omega.float(), d, synthesised.float()], dim=1)
        return torch.sigmoid(self.net(x).float())


class ReliabilityBiasedFusion(nn.Module):
    """Per-cell multi-head attention over {ego} U collaborators. The ego has reliability one and is
    always present, so as collaborator reliabilities vanish the output tends to a re-encoding of
    the ego feature plus the residual ego path."""

    def __init__(self, channels=64, heads=4, use_reliability=True, beta_init=1.0):
        super().__init__()
        assert channels % heads == 0
        self.heads = heads
        self.dh = channels // heads
        self.use_reliability = use_reliability
        self.q = nn.Conv2d(channels, channels, 1)
        self.k = nn.Conv2d(channels, channels, 1)
        self.v = nn.Conv2d(channels, channels, 1)
        self.o = nn.Conv2d(channels, channels, 1)
        self.beta_raw = nn.Parameter(torch.log(torch.expm1(torch.tensor(float(beta_init)))))
        self.post = ConvNormAct(channels, channels, 3)

    @property
    def beta(self):
        return F.softplus(self.beta_raw)

    def forward(self, f_ego, f_collab, reliability, available):
        """f_ego (B,C,H,W); f_collab (B,J,C,H,W); reliability, available (B,J,1,H,W)."""
        B, J, C, H, W = f_collab.shape
        feats = torch.cat([f_ego[:, None], f_collab.to(f_ego.dtype)], dim=1)  # (B, J+1, C, H, W)
        q = self.q(f_ego).view(B, self.heads, self.dh, H, W).float()
        k = self.k(feats.flatten(0, 1)).view(B, J + 1, self.heads, self.dh, H, W).float()
        v = self.v(feats.flatten(0, 1)).view(B, J + 1, self.heads, self.dh, H, W).float()
        logits = (q[:, None] * k).sum(dim=3) / self.dh ** 0.5  # (B, J+1, heads, H, W)
        if self.use_reliability:
            log_r = torch.log(reliability.float().clamp_min(1e-6))
            bias = torch.cat([torch.zeros_like(log_r[:, :1]), self.beta * log_r], dim=1)
            logits = logits + bias
        mask = torch.cat([torch.ones_like(available[:, :1]), available], dim=1) > 0.5
        logits = logits.masked_fill(~mask, float("-inf"))
        attn = logits.softmax(dim=1)
        out = (attn[:, :, :, None] * v).sum(dim=1).reshape(B, C, H, W)
        out = f_ego + self.o(out.to(f_ego.dtype))
        return self.post(out), attn


class MaxFusion(nn.Module):
    def forward(self, f_ego, f_collab, reliability, available):
        masked = torch.where(available > 0.5, f_collab.to(f_ego.dtype), torch.full_like(f_collab, -1e4).to(f_ego.dtype))
        fused = torch.maximum(f_ego, masked.amax(dim=1))
        return fused, None


def build_fusion(cfg, channels):
    kind = cfg.get("type", "attention")
    if kind == "attention":
        return ReliabilityBiasedFusion(
            channels, int(cfg.get("heads", 4)), bool(cfg.get("reliability_bias", True)), float(cfg.get("beta_init", 1.0))
        )
    if kind == "max":
        return MaxFusion()
    raise ValueError(f"unknown fusion type: {kind}")
