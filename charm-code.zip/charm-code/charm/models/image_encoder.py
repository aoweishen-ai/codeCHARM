"""Camera-to-BEV encoder: ResNet-50 image features, categorical depth distribution and splatting."""

import torch
import torch.nn as nn
import torch.nn.functional as F
import torchvision

from .common import ConvNormAct

IMAGENET_MEAN = (0.485, 0.456, 0.406)
IMAGENET_STD = (0.229, 0.224, 0.225)


class ImageBackbone(nn.Module):
    """ResNet-50 with a light top-down fusion of stride 16 and stride 32 features (output stride 16)."""

    def __init__(self, pretrained=True, out_channels=512):
        super().__init__()
        try:
            weights = torchvision.models.ResNet50_Weights.IMAGENET1K_V1 if pretrained else None
            net = torchvision.models.resnet50(weights=weights)
        except AttributeError:  # older torchvision
            net = torchvision.models.resnet50(pretrained=pretrained)
        self.stem = nn.Sequential(net.conv1, net.bn1, net.relu, net.maxpool)
        self.layer1, self.layer2, self.layer3, self.layer4 = net.layer1, net.layer2, net.layer3, net.layer4
        self.lat3 = nn.Conv2d(1024, out_channels, 1)
        self.lat4 = nn.Conv2d(2048, out_channels, 1)
        self.fuse = ConvNormAct(out_channels, out_channels, 3)

    def forward(self, x):
        x = self.layer2(self.layer1(self.stem(x)))
        c3 = self.layer3(x)
        c4 = self.layer4(c3)
        p = self.lat3(c3) + F.interpolate(self.lat4(c4), size=c3.shape[-2:], mode="bilinear", align_corners=False)
        return self.fuse(p)


class DepthLiftEncoder(nn.Module):
    """Lift multi-view image features to a BEV grid with a per-pixel categorical depth distribution."""

    def __init__(self, cfg, grid, z_range):
        super().__init__()
        self.grid = grid
        self.z_min, self.z_max = float(z_range[0]), float(z_range[1])
        self.stride = int(cfg.get("stride", 16))
        self.image_size = tuple(cfg["image_size"])
        n_bins = int(cfg.get("num_depth_bins", 59))
        self.depth_min = float(cfg.get("depth_min", 1.0))
        self.depth_step = float(cfg.get("depth_step", 0.85))
        self.register_buffer("depth_bins", self.depth_min + self.depth_step * torch.arange(n_bins).float())
        self.context_channels = int(cfg.get("context_channels", 64))
        feat = int(cfg.get("feat_channels", 512))
        self.backbone = ImageBackbone(cfg.get("pretrained", True), feat)
        self.depth_net = nn.Sequential(
            ConvNormAct(feat, feat, 3),
            nn.Conv2d(feat, n_bins + self.context_channels, 1),
        )
        self.register_buffer("frustum", self._make_frustum(), persistent=False)
        self.register_buffer("img_mean", torch.tensor(IMAGENET_MEAN).view(1, 3, 1, 1), persistent=False)
        self.register_buffer("img_std", torch.tensor(IMAGENET_STD).view(1, 3, 1, 1), persistent=False)

    @property
    def num_bins(self):
        return self.depth_bins.numel()

    def _make_frustum(self):
        H, W = self.image_size
        fh, fw = H // self.stride, W // self.stride
        us = (torch.arange(fw).float() + 0.5) * self.stride - 0.5
        vs = (torch.arange(fh).float() + 0.5) * self.stride - 0.5
        D = self.depth_bins.numel()
        d = self.depth_bins.view(D, 1, 1).expand(D, fh, fw)
        u = us.view(1, 1, fw).expand(D, fh, fw)
        v = vs.view(1, fh, 1).expand(D, fh, fw)
        return torch.stack([u * d, v * d, d], dim=-1)  # homogeneous pixel coordinates scaled by depth

    def geometry(self, intrinsics, cam2agent):
        """Agent-frame 3D location of every (view, depth bin, feature pixel): (N, V, D, h, w, 3)."""
        k_inv = torch.linalg.inv(intrinsics.float())
        cam = torch.einsum("nvij,dhwj->nvdhwi", k_inv, self.frustum)
        rot = cam2agent[..., :3, :3].float()
        trans = cam2agent[..., :3, 3].float()
        return torch.einsum("nvij,nvdhwj->nvdhwi", rot, cam) + trans[:, :, None, None, None, :]

    def voxel_pool(self, geom, feats):
        """Sum-pool lifted features into the BEV grid (z collapsed). geom (N,V,D,h,w,3), feats (...,C)."""
        g = self.grid
        N, C = geom.shape[0], feats.shape[-1]
        ix = torch.floor((geom[..., 0] - g.x_min) / g.res).long()
        iy = torch.floor((geom[..., 1] - g.y_min) / g.res).long()
        z = geom[..., 2]
        valid = (ix >= 0) & (ix < g.W) & (iy >= 0) & (iy < g.H) & (z >= self.z_min) & (z < self.z_max)
        batch_ix = torch.arange(N, device=geom.device).view(N, 1, 1, 1, 1).expand_as(ix)
        flat = (batch_ix * g.H + iy) * g.W + ix
        out = feats.new_zeros(N * g.H * g.W, C)
        out.index_add_(0, flat[valid], feats[valid])
        return out.view(N, g.H, g.W, C).permute(0, 3, 1, 2).contiguous()

    def forward(self, images, intrinsics, cam2agent):
        """images uint8/float (N, V, 3, H, W) -> BEV (N, C, Hb, Wb), depth logits (N, V, D, h, w)."""
        N, V = images.shape[:2]
        x = images.flatten(0, 1).float()
        if images.dtype == torch.uint8:
            x = x / 255.0
        x = (x - self.img_mean) / self.img_std
        x = self.depth_net(self.backbone(x))
        D = self.num_bins
        depth_logits = x[:, :D]
        context = x[:, D:]
        prob = depth_logits.float().softmax(dim=1)
        feats = prob.unsqueeze(2) * context.float().unsqueeze(1)  # (NV, D, C, h, w)
        feats = feats.permute(0, 1, 3, 4, 2)
        h, w = feats.shape[2:4]
        feats = feats.reshape(N, V, D, h, w, -1)
        geom = self.geometry(intrinsics, cam2agent)
        bev = self.voxel_pool(geom, feats)
        return bev, depth_logits.view(N, V, D, h, w)


def depth_loss(depth_logits, depth_gt, depth_min, depth_step):
    """Cross entropy between predicted depth bins and projected LiDAR depth (0 marks missing)."""
    D = depth_logits.shape[2]
    logits = depth_logits.permute(0, 1, 3, 4, 2).reshape(-1, D).float()
    gt = depth_gt.reshape(-1).float()
    idx = torch.round((gt - depth_min) / depth_step).long()
    valid = (gt > 0) & (idx >= 0) & (idx < D)
    if valid.sum() == 0:
        return logits.sum() * 0.0
    return F.cross_entropy(logits[valid], idx[valid])
