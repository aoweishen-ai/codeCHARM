"""CHARM: channel-adaptive camera V2X cooperative BEV detection.

Receive path per collaborator: dequantise and depacketise, rigidly align to the ego frame,
restore lost token groups with the conditional latent inpainter, push into the asynchronous
buffer, roll forward to the ego timestamp with the selective state space predictor, decode,
score reliability and fuse with reliability-biased attention.
"""

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

from ..channel.embedding import ChannelEmbedding
from ..channel.packet import simulate_link_losses
from ..utils.geometry import BEVGrid, morton_order, raster_order, warp_bev
from .bev_encoder import BEVEncoder
from .fusion import ReliabilityHead, build_fusion
from .head import CenterHead
from .image_encoder import DepthLiftEncoder, depth_loss
from .latent_codec import LatentCodec
from .message import MessageBuilder, groups_to_cells
from .pillar_encoder import PillarEncoder
from .predictors import build_predictor
from .restoration import build_restorer


def _flat_index(mask):
    return mask.reshape(-1).nonzero(as_tuple=True)[0]


def _scatter(values, index, total):
    out = values.new_zeros((total,) + tuple(values.shape[1:]))
    if index.numel() == 0:
        return out
    return out.index_copy(0, index, values)


def _masked_mean(x, mask):
    num = (x.float() * mask).sum()
    den = mask.sum() * x.shape[1]
    return num / den.clamp_min(1.0)


def _bernoulli_kl(p, q, eps=1e-6):
    p = p.clamp(eps, 1 - eps)
    q = q.clamp(eps, 1 - eps)
    return p * torch.log(p / q) + (1 - p) * torch.log((1 - p) / (1 - q))


class CHARM(nn.Module):
    def __init__(self, cfg):
        super().__init__()
        self.cfg = cfg
        m = cfg["model"]
        self.modality = m.get("modality", "camera")
        b = m["bev"]
        self.splat_grid = BEVGrid(b["x_range"], b["y_range"], b["resolution"])
        self.grid = self.splat_grid.downsample(2)
        C = int(m.get("bev_channels", 64))
        self.C = C

        if self.modality == "camera":
            ie = dict(m["image_encoder"])
            ie["image_size"] = cfg["dataset"]["image_size"]
            self.sensor_encoder = DepthLiftEncoder(ie, self.splat_grid, b["z_range"])
            in_ch = self.sensor_encoder.context_channels
        else:
            pc = m.get("pillar", {})
            in_ch = int(pc.get("channels", 64))
            self.sensor_encoder = PillarEncoder(self.splat_grid, b["z_range"], in_ch, int(pc.get("point_dim", 4)))
        self.bev_encoder = BEVEncoder(in_ch, C)

        lat = m["latent"]
        self.latent_ch = int(lat.get("channels", 16))
        self.group_size = int(lat.get("group_size", 8))
        self.gh, self.gw = self.grid.H // self.group_size, self.grid.W // self.group_size
        self.num_groups = self.gh * self.gw
        self.codec = LatentCodec(C, self.latent_ch)

        ce = m.get("channel_embedding", {})
        dc = int(ce.get("dim", 64))
        self.cond_dim = dc
        self.channel_embed = ChannelEmbedding(dc, 4, int(ce.get("num_frequencies", 8)), float(ce.get("sigma", 2.0)))
        self.use_channel_state = bool(ce.get("enabled", True))

        self.messenger = MessageBuilder(m.get("message", {}), self.latent_ch, dc, self.group_size)
        self.restorer = build_restorer(m.get("restorer", {}), self.latent_ch, dc)
        period = float(cfg["dataset"].get("frame_period", 0.1))
        self.predictor = build_predictor(m.get("predictor", {}), self.latent_ch, dc, period)
        self.reliability = ReliabilityHead(dc)
        self.fusion = build_fusion(m.get("fusion", {}), C)
        hc = m.get("head", {})
        self.head = CenterHead(
            C, self.grid, num_classes=int(hc.get("num_classes", 1)),
            reg_weight=float(cfg.get("loss", {}).get("reg_weight", 0.25)),
        )
        self.det_cfg = hc
        self.order = m.get("order", "restore_first")
        self.loss_w = cfg.get("loss", {})
        order = cfg.get("channel", {}).get("packet_order", "morton")
        self.packet_order = morton_order(self.gh, self.gw) if order == "morton" else raster_order(self.gh, self.gw)

    # ----------------------------------------------------------------------------- encoding
    def _encode(self, batch, prefix, valid):
        """Encode the agent-frames selected by ``valid`` (any leading shape) to BEV features."""
        lead = tuple(valid.shape)
        n_total = int(np.prod(lead))
        idx = _flat_index(valid)
        H, W = self.grid.H, self.grid.W
        depth_logits = None
        ref = batch[prefix + ("imgs" if self.modality == "camera" else "points")]
        if idx.numel() == 0:
            feats = torch.zeros(n_total, self.C, H, W, device=ref.device)
            return feats.view(*lead, self.C, H, W), None, idx
        if self.modality == "camera":
            imgs = batch[prefix + "imgs"].reshape(n_total, *batch[prefix + "imgs"].shape[len(lead):])[idx]
            intr = batch[prefix + "intr"].reshape(n_total, -1, 3, 3)[idx]
            c2a = batch[prefix + "cam2agent"].reshape(n_total, -1, 4, 4)[idx]
            bev, depth_logits = self.sensor_encoder(imgs, intr, c2a)
        else:
            pts = batch[prefix + "points"]
            pts = pts.reshape(n_total, *pts.shape[len(lead):])[idx]
            num = batch[prefix + "num_points"].reshape(n_total)[idx]
            bev = self.sensor_encoder(pts, num)
        feats = self.bev_encoder(bev)
        feats = _scatter(feats, idx, n_total)
        return feats.view(*lead, self.C, H, W), depth_logits, idx

    # ----------------------------------------------------------------------------- channel
    def _packet_loss(self, sent, ge_params, seeds):
        """sent (B, J, K, G) bool -> survived (B, J, K, G) bool."""
        B, J, K, G = sent.shape
        sent_np = sent.detach().cpu().numpy()
        ge_np = ge_params.detach().float().cpu().numpy()
        seed_np = seeds.detach().cpu().numpy()
        out = np.zeros_like(sent_np)
        for b in range(B):
            for j in range(J):
                if sent_np[b, j].any():
                    out[b, j] = simulate_link_losses(sent_np[b, j], ge_np[b, j], int(seed_np[b, j]), self.packet_order)
        return torch.from_numpy(out).to(sent.device)

    def _embed_channel(self, scalars):
        scalars = scalars.reshape(-1, scalars.shape[-1]).float()
        if not self.use_channel_state:
            scalars = torch.zeros_like(scalars)
        return self.channel_embed(scalars)

    def _cells(self, groups):
        return groups_to_cells(groups.float(), self.group_size, self.gh, self.gw)

    def _predict(self, lat_all, aux_all, times, valid, z_c, lidx):
        B, J, K = valid.shape
        L = B * J
        Cl, H, W = self.latent_ch, self.grid.H, self.grid.W
        if lidx.numel() == 0:
            empty = lat_all.new_zeros(0, Cl, H, W)
            return empty, lat_all.new_zeros(0, 1, H, W)
        lat = lat_all.reshape(L, K, *lat_all.shape[3:])[lidx]
        aux = aux_all.reshape(L, K, *aux_all.shape[3:])[lidx]
        t = times.reshape(L, K)[lidx]
        v = valid.reshape(L, K)[lidx]
        z = z_c.reshape(L, -1)[lidx]
        t_ego = torch.zeros(lidx.numel(), device=lat.device)
        u_hat, omega, _ = self.predictor(lat, aux, t, v, t_ego, z)
        return u_hat.float(), omega.float()

    # ----------------------------------------------------------------------------- forward
    def forward(self, batch, return_loss=False):
        hist_valid = batch["hist_valid"].bool()
        present = batch["present"].bool()
        B, J, K = hist_valid.shape
        H, W, C, Cl = self.grid.H, self.grid.W, self.C, self.latent_ch
        G = self.num_groups
        N, L = B * J * K, B * J
        dev = hist_valid.device

        # ego agent
        ego_valid = torch.ones(B, dtype=torch.bool, device=dev)
        F_e, ego_dl, _ = self._encode(batch, "ego_", ego_valid)
        u_e = self.codec.encode(F_e).float()
        z_c = self._embed_channel(batch["channel_scalars"]).view(B, J, -1)
        dc = z_c.shape[-1]

        # sender side: encode history frames and build budgeted messages
        F_h, hist_dl, hidx = self._encode(batch, "hist_", hist_valid)
        F_hv = F_h.reshape(N, C, H, W)[hidx]
        u_hv = self.codec.encode(F_hv).float()
        conf_hv = self.head.confidence(F_hv).detach()
        z_hv = z_c[:, :, None].expand(B, J, K, dc).reshape(N, dc)[hidx]
        budget_hv = batch["budget"][:, :, None].expand(B, J, K).reshape(N)[hidx].float()
        msg = self.messenger(u_hv, conf_hv, z_hv, budget_hv)

        # channel: burst packet loss on the transmitted token groups
        sent = _scatter(msg["sent"].float(), hidx, N).view(B, J, K, G) > 0.5
        survived = self._packet_loss(sent, batch["ge_params"], batch["link_seed"])
        valid = hist_valid & survived.any(dim=-1)

        u_sent = _scatter(msg["u"], hidx, N)
        surv_cells = self._cells(survived.reshape(N, G))
        sent_cells = self._cells(sent.reshape(N, G))
        u_rx = u_sent * surv_cells

        # receive side: rigid alignment into the ego frame with the reported (noisy) pose
        vidx = _flat_index(valid)
        T_v = batch["hist_T"].reshape(N, 4, 4)[vidx].float()
        u_rx_v = warp_bev(u_rx[vidx], T_v, self.grid)
        M_v = (warp_bev(surv_cells[vidx], T_v, self.grid, mode="nearest") > 0.5).float()
        S_v = (warp_bev(sent_cells[vidx], T_v, self.grid, mode="nearest") > 0.5).float()
        fov_v = (warp_bev(torch.ones_like(surv_cells[vidx]), T_v, self.grid, mode="nearest") > 0.5).float()
        u_ego_v = u_e[:, None, None].expand(B, J, K, Cl, H, W).reshape(N, Cl, H, W)[vidx]
        z_v = z_c[:, :, None].expand(B, J, K, dc).reshape(N, dc)[vidx]
        times = batch["hist_times"].float()

        link_ok = valid.any(dim=-1) & present
        lidx = _flat_index(link_ok)
        last_idx = (valid.long() * torch.arange(1, K + 1, device=dev)).argmax(dim=-1)
        t_last = times.gather(-1, last_idx[..., None]).squeeze(-1)
        horizon = (-t_last).clamp_min(0.0) * link_ok.float()

        def per_entry(x_v):
            return _scatter(x_v, vidx, N).view(B, J, K, *x_v.shape[1:])

        def last_entry(x_all):
            idx = last_idx.view(B, J, 1, 1, 1, 1).expand(B, J, 1, *x_all.shape[3:])
            return x_all.gather(2, idx).squeeze(2)

        M_all, S_all = per_entry(M_v), per_entry(S_v)
        M_last, S_last = last_entry(M_all), last_entry(S_all)

        if self.order == "restore_first":
            with torch.no_grad():
                gen_v, var_v = self.restorer.restore(u_rx_v.detach(), M_v, u_ego_v.detach(), z_v.detach())
            u_inp_v = M_v * u_rx_v + (1 - M_v) * gen_v
            var_all = per_entry(var_v)
            aux_all = torch.cat([M_all, torch.log1p(var_all)], dim=3)
            var_last = last_entry(var_all)
            u_hat_l, omega_l = self._predict(per_entry(u_inp_v), aux_all, times, valid, z_c, lidx)
        else:
            aux_all = torch.cat([M_all, torch.zeros_like(M_all)], dim=3)
            u_fwd_l, omega_l = self._predict(per_entry(u_rx_v), aux_all, times, valid, z_c, lidx)
            M_last_l = M_last.reshape(L, 1, H, W)[lidx]
            u_e_l = u_e[:, None].expand(B, J, Cl, H, W).reshape(L, Cl, H, W)[lidx]
            z_l = z_c.reshape(L, dc)[lidx]
            with torch.no_grad():
                gen_l, var_l = self.restorer.restore(u_fwd_l.detach(), M_last_l, u_e_l, z_l)
            u_hat_l = M_last_l * u_fwd_l + (1 - M_last_l) * gen_l
            var_last = _scatter(var_l, lidx, L).view(B, J, 1, H, W)

        u_hat = _scatter(u_hat_l, lidx, L).view(B, J, Cl, H, W)
        omega = _scatter(omega_l, lidx, L).view(B, J, 1, H, W)
        F_hat = self.codec.decode(u_hat.reshape(L, Cl, H, W)).view(B, J, C, H, W)

        r = self.reliability(
            z_c.reshape(L, dc), var_last.reshape(L, 1, H, W), omega.reshape(L, 1, H, W),
            horizon.reshape(L), (1 - M_last).reshape(L, 1, H, W),
        ).view(B, J, 1, H, W)
        avail = S_last * link_ok.view(B, J, 1, 1, 1).float()
        F_fus, attn = self.fusion(F_e, F_hat, r, avail)
        preds = self.head(F_fus)

        last_sent = (hist_valid.long() * torch.arange(1, K + 1, device=dev)).argmax(dim=-1)
        bytes_all = _scatter(msg["bytes"].float(), hidx, N).view(B, J, K)
        out = {
            "preds": preds,
            "reliability": r,
            "available": avail,
            "link_ok": link_ok,
            "link_active": hist_valid.any(dim=-1) & present,
            "bytes": bytes_all.gather(-1, last_sent[..., None]).squeeze(-1),
        }
        if not return_loss:
            out["detections"] = self.head.decode(
                preds,
                score_threshold=float(self.det_cfg.get("score_threshold", 0.05)),
                nms_iou=float(self.det_cfg.get("nms_iou", 0.15)),
                max_det=int(self.det_cfg.get("max_det", 100)),
            )
            return out

        # ----------------------------------------------------------------------------- losses
        w = self.loss_w
        losses = {}
        targets = self.head.build_targets(batch["gt_boxes"], batch["gt_mask"], batch.get("gt_cls"))
        losses["det"] = self.head.loss(preds, targets)

        if self.modality == "camera" and float(w.get("depth", 0.0)) > 0 and "ego_depth" in batch:
            enc = self.sensor_encoder
            terms = [depth_loss(ego_dl, batch["ego_depth"], enc.depth_min, enc.depth_step)]
            if hist_dl is not None and hidx.numel() > 0:
                gt_h = batch["hist_depth"].reshape(N, *batch["hist_depth"].shape[3:])[hidx]
                terms.append(depth_loss(hist_dl, gt_h, enc.depth_min, enc.depth_step))
            losses["depth"] = sum(terms) / len(terms)

        F_det = torch.cat([F_e, F_hv], dim=0).detach()
        losses["rec"] = (self.codec.decode(self.codec.encode(F_det)) - F_det).abs().mean()

        finite = torch.isfinite(budget_hv)
        if finite.any():
            over = F.relu(msg["exp_bytes"][finite] - budget_hv[finite]) / budget_hv[finite]
            losses["bw"] = over.mean()

        if vidx.numel() > 0:
            u_full_v = warp_bev(_scatter(u_hv, hidx, N)[vidx], T_v, self.grid).detach()
            l_diff, x0_hat, w_t = self.restorer.loss(
                u_full_v, u_rx_v.detach(), M_v, fov_v, u_ego_v.detach(), z_v.detach()
            )
            losses["diff"] = l_diff
            if x0_hat is not None and float(w.get("cons", 0.0)) > 0:
                F_full_v = warp_bev(F_h.reshape(N, C, H, W)[vidx].float(), T_v, self.grid).detach()
                region = fov_v * w_t.view(-1, 1, 1, 1)
                F_rec = self.codec.decode(x0_hat)
                l1 = _masked_mean((F_rec.float() - F_full_v).abs(), region)
                p = self.head.confidence(F_rec)
                with torch.no_grad():
                    q = self.head.confidence(F_full_v)
                losses["cons"] = l1 + _masked_mean(_bernoulli_kl(p, q), region)

        if "tgt_valid" in batch and lidx.numel() > 0:
            tgt_ok = batch["tgt_valid"].bool() & link_ok
            tidx = _flat_index(tgt_ok)
            if tidx.numel() > 0:
                with torch.no_grad():
                    F_t, _, _ = self._encode(batch, "tgt_", tgt_ok)
                    F_t = F_t.reshape(L, C, H, W)[tidx].float()
                    T_t = batch["tgt_T"].reshape(L, 4, 4)[tidx].float()
                    u_t_e = warp_bev(self.codec.encode(F_t).float(), T_t, self.grid)
                    F_t_e = warp_bev(F_t, T_t, self.grid)
                    fov_t = (warp_bev(torch.ones_like(F_t[:, :1]), T_t, self.grid, mode="nearest") > 0.5).float()
                u_hat_t = u_hat.reshape(L, Cl, H, W)[tidx]
                cos = F.cosine_similarity(u_hat_t, u_t_e, dim=1, eps=1e-6)[:, None]
                losses["fore"] = _masked_mean((u_hat_t - u_t_e).abs(), fov_t) + float(w.get("cos", 0.5)) * _masked_mean(1 - cos, fov_t)

                F_hat_t = F_hat.reshape(L, C, H, W)[tidx].float()
                err = (F_hat_t.detach() - F_t_e).norm(dim=1, keepdim=True) / (F_t_e.norm(dim=1, keepdim=True) + 1e-3)
                target = (1.0 - err).clamp(0.0, 1.0)
                r_t = r.reshape(L, 1, H, W)[tidx].clamp(1e-6, 1 - 1e-6)
                bce = -(target * torch.log(r_t) + (1 - target) * torch.log(1 - r_t))
                losses["rel"] = _masked_mean(bce, avail.reshape(L, 1, H, W)[tidx] * fov_t)

        total = losses["det"]
        for key in ("fore", "diff", "cons", "bw", "rel", "depth", "rec"):
            if key in losses:
                total = total + float(w.get(key, 0.0)) * losses[key]
        out["losses"] = {k: v.detach() for k, v in losses.items()}
        out["loss"] = total
        return out

    # ----------------------------------------------------------------------------- distillation data
    @torch.no_grad()
    def restoration_samples(self, batch):
        """Run the sender and channel and return the inputs of the inpainting task for distillation."""
        hist_valid = batch["hist_valid"].bool()
        B, J, K = hist_valid.shape
        H, W, C, Cl, G = self.grid.H, self.grid.W, self.C, self.latent_ch, self.num_groups
        N, L = B * J * K, B * J
        ego_valid = torch.ones(B, dtype=torch.bool, device=hist_valid.device)
        F_e, _, _ = self._encode(batch, "ego_", ego_valid)
        u_e = self.codec.encode(F_e).float()
        z_c = self._embed_channel(batch["channel_scalars"]).view(B, J, -1)
        dc = z_c.shape[-1]
        F_h, _, hidx = self._encode(batch, "hist_", hist_valid)
        F_hv = F_h.reshape(N, C, H, W)[hidx]
        u_hv = self.codec.encode(F_hv).float()
        conf_hv = self.head.confidence(F_hv)
        z_hv = z_c[:, :, None].expand(B, J, K, dc).reshape(N, dc)[hidx]
        budget_hv = batch["budget"][:, :, None].expand(B, J, K).reshape(N)[hidx].float()
        msg = self.messenger(u_hv, conf_hv, z_hv, budget_hv)
        sent = _scatter(msg["sent"].float(), hidx, N).view(B, J, K, G) > 0.5
        survived = self._packet_loss(sent, batch["ge_params"], batch["link_seed"])
        valid = hist_valid & survived.any(dim=-1)
        vidx = _flat_index(valid)
        T_v = batch["hist_T"].reshape(N, 4, 4)[vidx].float()
        surv_cells = self._cells(survived.reshape(N, G))
        u_rx = _scatter(msg["u"], hidx, N) * surv_cells
        return {
            "u0": warp_bev(_scatter(u_hv, hidx, N)[vidx], T_v, self.grid),
            "u_known": warp_bev(u_rx[vidx], T_v, self.grid),
            "mask": (warp_bev(surv_cells[vidx], T_v, self.grid, mode="nearest") > 0.5).float(),
            "region": (warp_bev(torch.ones_like(surv_cells[vidx]), T_v, self.grid, mode="nearest") > 0.5).float(),
            "u_ego": u_e[:, None, None].expand(B, J, K, Cl, H, W).reshape(N, Cl, H, W)[vidx],
            "z_c": z_c[:, :, None].expand(B, J, K, dc).reshape(N, dc)[vidx],
        }


def build_model(cfg):
    return CHARM(cfg)
