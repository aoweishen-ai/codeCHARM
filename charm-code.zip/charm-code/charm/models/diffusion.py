"""Conditional latent diffusion inpainting of lost BEV tokens with known-region replacement,
and its consistency-distilled few-step student."""

import copy
import math

import torch
import torch.nn as nn
import torch.nn.functional as F

from .common import group_norm


def cosine_alphas_cumprod(T, s=0.008):
    steps = torch.arange(T + 1, dtype=torch.float64) / T
    f = torch.cos((steps + s) / (1 + s) * math.pi / 2) ** 2
    ac = f / f[0]
    betas = (1 - ac[1:] / ac[:-1]).clamp(0.0, 0.999)
    return torch.cumprod(1.0 - betas, dim=0).float()


def timestep_embedding(t, dim, max_period=10000.0):
    half = dim // 2
    freqs = torch.exp(-math.log(max_period) * torch.arange(half, device=t.device, dtype=torch.float32) / half)
    args = t.float()[:, None] * freqs[None]
    return torch.cat([torch.cos(args), torch.sin(args)], dim=-1)


class CondResBlock(nn.Module):
    def __init__(self, cin, cout, emb_dim):
        super().__init__()
        self.norm1 = group_norm(cin)
        self.conv1 = nn.Conv2d(cin, cout, 3, padding=1)
        self.emb = nn.Linear(emb_dim, 2 * cout)
        self.norm2 = group_norm(cout)
        self.conv2 = nn.Conv2d(cout, cout, 3, padding=1)
        nn.init.zeros_(self.conv2.weight)
        nn.init.zeros_(self.conv2.bias)
        self.skip = nn.Conv2d(cin, cout, 1) if cin != cout else nn.Identity()

    def forward(self, x, emb):
        h = self.conv1(F.silu(self.norm1(x)))
        gamma, beta = self.emb(F.silu(emb)).chunk(2, dim=1)
        h = self.norm2(h) * (1 + gamma[..., None, None]) + beta[..., None, None]
        h = self.conv2(F.silu(h))
        return self.skip(x) + h


class InpaintUNet(nn.Module):
    """Three-scale U-Net. Input: noisy latent, loss mask, aligned ego latent and broadcast channel
    embedding; the diffusion timestep and the channel embedding modulate every residual block."""

    def __init__(self, latent_channels=16, cond_dim=64, base=64, mults=(1, 2, 2), emb_dim=256, zc_channels=8):
        super().__init__()
        self.base = base
        self.zc_map = nn.Linear(cond_dim, zc_channels)
        self.t_mlp = nn.Sequential(nn.Linear(base, emb_dim), nn.SiLU(), nn.Linear(emb_dim, emb_dim))
        self.c_mlp = nn.Sequential(nn.Linear(cond_dim, emb_dim), nn.SiLU(), nn.Linear(emb_dim, emb_dim))
        self.conv_in = nn.Conv2d(2 * latent_channels + 1 + zc_channels, base, 3, padding=1)

        chs = [base * m for m in mults]
        self.down_blocks = nn.ModuleList()
        self.downsamplers = nn.ModuleList()
        cur = base
        for i, ch in enumerate(chs):
            self.down_blocks.append(nn.ModuleList([CondResBlock(cur, ch, emb_dim), CondResBlock(ch, ch, emb_dim)]))
            cur = ch
            self.downsamplers.append(
                nn.Conv2d(ch, ch, 3, stride=2, padding=1) if i < len(chs) - 1 else nn.Identity()
            )
        self.mid = nn.ModuleList([CondResBlock(cur, cur, emb_dim), CondResBlock(cur, cur, emb_dim)])
        self.up_blocks = nn.ModuleList()
        self.upsamplers = nn.ModuleList()
        for i in reversed(range(len(chs))):
            ch = chs[i]
            self.up_blocks.append(
                nn.ModuleList([CondResBlock(cur + chs[i], ch, emb_dim), CondResBlock(ch, ch, emb_dim)])
            )
            cur = ch
            self.upsamplers.append(
                nn.Sequential(nn.Upsample(scale_factor=2, mode="nearest"), nn.Conv2d(ch, ch, 3, padding=1))
                if i > 0 else nn.Identity()
            )
        self.out = nn.Sequential(group_norm(cur), nn.SiLU(), nn.Conv2d(cur, latent_channels, 3, padding=1))
        nn.init.zeros_(self.out[-1].weight)
        nn.init.zeros_(self.out[-1].bias)

    def forward(self, x, t, mask, u_ego, z_c):
        N, _, H, W = x.shape
        zc_map = self.zc_map(z_c.float())[:, :, None, None].expand(-1, -1, H, W).to(x.dtype)
        h = self.conv_in(torch.cat([x, mask.to(x.dtype), u_ego.to(x.dtype), zc_map], dim=1))
        emb = self.t_mlp(timestep_embedding(t, self.base)) + self.c_mlp(z_c.float())
        skips = []
        for blocks, down in zip(self.down_blocks, self.downsamplers):
            for blk in blocks:
                h = blk(h, emb)
            skips.append(h)
            h = down(h)
        for blk in self.mid:
            h = blk(h, emb)
        for blocks, up in zip(self.up_blocks, self.upsamplers):
            h = torch.cat([h, skips.pop()], dim=1)
            for blk in blocks:
                h = blk(h, emb)
            h = up(h)
        return self.out(h)


class LatentDiffusionInpainter(nn.Module):
    """Teacher: epsilon-prediction latent diffusion trained on the lost region only.
    Student: consistency model sharing the architecture, used with two function evaluations."""

    def __init__(self, cfg, latent_channels, cond_dim):
        super().__init__()
        self.T = int(cfg.get("timesteps", 1000))
        self.teacher_steps = int(cfg.get("teacher_steps", 8))
        self.train_steps = int(cfg.get("train_steps", 4))
        self.student_timesteps = [int(t) for t in cfg.get("student_timesteps", [self.T - 1, 400])]
        self.num_samples = int(cfg.get("num_samples", 2))
        self.use_ego = bool(cfg.get("ego_conditioning", True))
        self.x0_clip = float(cfg.get("x0_clip", 10.0))
        self.sigma_data = float(cfg.get("sigma_data", 0.5))
        self.register_buffer("ac", cosine_alphas_cumprod(self.T), persistent=False)
        unet_kwargs = dict(
            latent_channels=latent_channels, cond_dim=cond_dim,
            base=int(cfg.get("base_channels", 64)), mults=tuple(cfg.get("channel_mults", [1, 2, 2])),
        )
        self.net = InpaintUNet(**unet_kwargs)
        self.student = InpaintUNet(**unet_kwargs)
        self.student.requires_grad_(False)
        self.register_buffer("student_ready", torch.zeros((), dtype=torch.bool))

    # ----------------------------------------------------------------- diffusion utilities
    def _a(self, t):
        return self.ac[t].view(-1, 1, 1, 1)

    def q_sample(self, x0, t, noise):
        a = self._a(t)
        return a.sqrt() * x0 + (1 - a).sqrt() * noise

    def predict_x0(self, x_t, t, eps):
        a = self._a(t)
        x0 = (x_t - (1 - a).sqrt() * eps) / a.sqrt()
        return x0.clamp(-self.x0_clip, self.x0_clip)

    def _cond(self, u_ego):
        return u_ego if self.use_ego else torch.zeros_like(u_ego)

    # ----------------------------------------------------------------- training
    def loss(self, u0, u_known, mask, region, u_ego, z_c):
        """Masked denoising loss. Returns (loss, one-step clean estimate, per-sample weight)."""
        N = u0.shape[0]
        if N == 0:
            return u0.sum() * 0.0, None, None
        t = torch.randint(0, self.T, (N,), device=u0.device)
        noise = torch.randn_like(u0)
        x_start = mask * u_known + (1 - mask) * u0
        x_t = self.q_sample(x_start, t, noise)
        eps = self.net(x_t, t, mask, self._cond(u_ego), z_c)
        w = (1 - mask) * region
        loss = (w * (noise - eps.float()) ** 2).sum() / (w.sum() * u0.shape[1]).clamp_min(1.0)
        x0 = self.predict_x0(x_t, t, eps.float())
        x0_hat = mask * u_known + (1 - mask) * x0
        return loss, x0_hat, self.ac[t]

    # ----------------------------------------------------------------- samplers
    @torch.no_grad()
    def ddim_sample(self, u_known, mask, u_ego, z_c, steps, net=None):
        """Deterministic DDIM trajectory with the known region replaced at every step."""
        net = net or self.net
        u_ego = self._cond(u_ego)
        ts = torch.linspace(self.T - 1, 0, steps, device=u_known.device).round().long()
        x = torch.randn_like(u_known)
        for i in range(len(ts)):
            t = ts[i].expand(u_known.shape[0])
            known_t = self.q_sample(u_known, t, torch.randn_like(u_known))
            x = mask * known_t + (1 - mask) * x
            eps = net(x, t, mask, u_ego, z_c).float()
            x0 = self.predict_x0(x, t, eps)
            if i + 1 < len(ts):
                a_prev = self._a(ts[i + 1].expand(u_known.shape[0]))
                x = a_prev.sqrt() * x0 + (1 - a_prev).sqrt() * eps
            else:
                x = x0
        return mask * u_known + (1 - mask) * x

    def _sigma(self, t):
        a = self.ac[t]
        return ((1 - a) / a).sqrt()

    def consistency(self, net, x_t, t, mask, u_ego, z_c):
        """Consistency function with the boundary condition f(x, t_min) = x."""
        eps = net(x_t, t, mask, u_ego, z_c).float()
        x0 = self.predict_x0(x_t, t, eps)
        sigma = self._sigma(t).view(-1, 1, 1, 1)
        sigma_min = self._sigma(torch.zeros_like(t)).view(-1, 1, 1, 1)
        c_skip = self.sigma_data ** 2 / ((sigma - sigma_min) ** 2 + self.sigma_data ** 2)
        x_scaled = (x_t / self._a(t).sqrt()).clamp(-self.x0_clip, self.x0_clip)
        return c_skip * x_scaled + (1 - c_skip) * x0

    @torch.no_grad()
    def student_sample(self, u_known, mask, u_ego, z_c):
        u_ego = self._cond(u_ego)
        x0 = None
        for i, t_val in enumerate(self.student_timesteps):
            t = torch.full((u_known.shape[0],), t_val, device=u_known.device, dtype=torch.long)
            if i == 0:
                x_t = torch.randn_like(u_known)
            else:
                x_t = self.q_sample(x0, t, torch.randn_like(u_known))
            x_t = mask * self.q_sample(u_known, t, torch.randn_like(u_known)) + (1 - mask) * x_t
            x0 = self.consistency(self.student, x_t, t, mask, u_ego, z_c)
            x0 = mask * u_known + (1 - mask) * x0
        return x0

    @torch.no_grad()
    def restore(self, u_known, mask, u_ego, z_c, num_samples=None):
        """Return the mean of S stochastic completions and the per-cell dispersion (N, 1, H, W)."""
        N, C, H, W = u_known.shape
        if N == 0:
            return torch.zeros_like(u_known), u_known.new_zeros(0, 1, H, W)
        S = int(num_samples or self.num_samples)

        def rep(x):
            return x.repeat(S, *([1] * (x.dim() - 1)))

        uk, m, ue, zc = rep(u_known.float()), rep(mask.float()), rep(u_ego.float()), rep(z_c.float())
        if self.training:
            samples = self.ddim_sample(uk, m, ue, zc, self.train_steps)
        elif bool(self.student_ready):
            samples = self.student_sample(uk, m, ue, zc)
        else:
            samples = self.ddim_sample(uk, m, ue, zc, self.teacher_steps)
        samples = samples.view(S, N, C, H, W)
        mean = samples.mean(dim=0)
        var = ((samples - mean) ** 2).sum(dim=2, keepdim=True).mean(dim=0)
        return mean, var

    def init_student_from_teacher(self):
        self.student.load_state_dict(self.net.state_dict())


class ConsistencyDistiller:
    """Distils the DDIM teacher into the consistency student on the masked inpainting task."""

    def __init__(self, inpainter, num_intervals=40, ema_decay=0.999, huber_c=0.03):
        self.m = inpainter
        self.ema_decay = float(ema_decay)
        self.huber_c = float(huber_c)
        self.m.init_student_from_teacher()
        self.m.student.requires_grad_(True)
        self.m.net.requires_grad_(False)
        self.target = copy.deepcopy(self.m.student).requires_grad_(False)
        self.boundaries = torch.linspace(0, self.m.T - 1, num_intervals + 1).round().long()

    def parameters(self):
        return self.m.student.parameters()

    def loss(self, u0, u_known, mask, region, u_ego, z_c):
        m = self.m
        N = u0.shape[0]
        device = u0.device
        if N == 0:
            return u0.sum() * 0.0
        u_ego = m._cond(u_ego)
        bnd = self.boundaries.to(device)
        n = torch.randint(0, len(bnd) - 1, (N,), device=device)
        t_next, t_cur = bnd[n + 1], bnd[n]
        noise = torch.randn_like(u0)
        x_start = mask * u_known + (1 - mask) * u0
        x_next = m.q_sample(x_start, t_next, noise)
        with torch.no_grad():
            eps = m.net(x_next, t_next, mask, u_ego, z_c).float()
            x0 = m.predict_x0(x_next, t_next, eps)
            a_cur = m._a(t_cur)
            x_cur = a_cur.sqrt() * x0 + (1 - a_cur).sqrt() * eps
            x_cur = mask * m.q_sample(u_known, t_cur, noise) + (1 - mask) * x_cur
            target = m.consistency(self.target, x_cur, t_cur, mask, u_ego, z_c)
        pred = m.consistency(m.student, x_next, t_next, mask, u_ego, z_c)
        w = (1 - mask) * region
        dist = torch.sqrt((pred - target) ** 2 + self.huber_c ** 2) - self.huber_c
        return (w * dist).sum() / (w.sum() * u0.shape[1]).clamp_min(1.0)

    @torch.no_grad()
    def update_ema(self):
        for p_t, p_s in zip(self.target.parameters(), self.m.student.parameters()):
            p_t.mul_(self.ema_decay).add_(p_s.detach(), alpha=1 - self.ema_decay)

    def finalize(self):
        self.m.student.load_state_dict(self.target.state_dict())
        self.m.student.requires_grad_(False)
        self.m.student_ready.fill_(True)
