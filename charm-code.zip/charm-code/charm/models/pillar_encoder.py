"""PointPillars-style LiDAR encoder used by the LiDAR variant."""

import torch
import torch.nn as nn


class PillarEncoder(nn.Module):
    def __init__(self, grid, z_range, out_channels=64, point_dim=4):
        super().__init__()
        self.grid = grid
        self.z_min, self.z_max = float(z_range[0]), float(z_range[1])
        self.out_channels = out_channels
        self.linear = nn.Linear(point_dim + 5, out_channels, bias=False)
        self.norm = nn.BatchNorm1d(out_channels)

    def forward(self, points, num_points):
        g = self.grid
        N = points.shape[0]
        canvases = []
        for n in range(N):
            canvas = points.new_zeros(self.out_channels, g.H * g.W)
            p = points[n, : int(num_points[n])].float()
            if p.shape[0] > 0:
                keep = (
                    (p[:, 0] >= g.x_min) & (p[:, 0] < g.x_max) & (p[:, 1] >= g.y_min) & (p[:, 1] < g.y_max)
                    & (p[:, 2] >= self.z_min) & (p[:, 2] < self.z_max)
                )
                p = p[keep]
            if p.shape[0] > 0:
                ix = torch.floor((p[:, 0] - g.x_min) / g.res).long().clamp(0, g.W - 1)
                iy = torch.floor((p[:, 1] - g.y_min) / g.res).long().clamp(0, g.H - 1)
                pid = iy * g.W + ix
                uniq, inv = torch.unique(pid, return_inverse=True)
                count = torch.bincount(inv, minlength=uniq.numel()).clamp(min=1).float()
                mean = p.new_zeros(uniq.numel(), 3).index_add_(0, inv, p[:, :3]) / count[:, None]
                cx = g.x_min + (ix.float() + 0.5) * g.res
                cy = g.y_min + (iy.float() + 0.5) * g.res
                feats = torch.cat(
                    [p, p[:, :3] - mean[inv], (p[:, 0] - cx)[:, None], (p[:, 1] - cy)[:, None]], dim=1
                )
                feats = torch.relu(self.norm(self.linear(feats)))
                pillar = feats.new_zeros(uniq.numel(), self.out_channels)
                pillar = pillar.scatter_reduce(
                    0, inv[:, None].expand(-1, self.out_channels), feats, reduce="amax", include_self=True
                )
                canvas = canvas.to(pillar.dtype)
                canvas[:, uniq] = pillar.t()
            canvases.append(canvas.view(self.out_channels, g.H, g.W))
        return torch.stack(canvases, dim=0)
