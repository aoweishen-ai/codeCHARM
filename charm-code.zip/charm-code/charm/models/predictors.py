"""Temporal predictors used for latency compensation. All share the SSMPredictor interface:

    forward(lat, aux, times, valid, t_ego, z_c) -> (aligned latent, validity omega, offsets)
"""

import torch
import torch.nn as nn

from .common import ConvNormAct, TimeEncoding
from .ssm import SSMPredictor, last_valid_index, physical_gaps
from .warp import WarpHead, flow_warp


class GRUPredictor(nn.Module):
    """Per-location gated recurrent unit; the physical gap is fed as an input feature."""

    def __init__(self, cfg, latent_channels, cond_dim, frame_period=0.1):
        super().__init__()
        d = int(cfg.get("d_model", 128))
        self.period = float(frame_period)
        self.inp = nn.Linear(latent_channels + 2, d)
        self.gap_enc = TimeEncoding(d)
        self.cond = nn.Linear(cond_dim, d)
        self.cell = nn.GRUCell(d, d)
        self.out = nn.Linear(d, latent_channels)
        self.warp_head = WarpHead(d + 2, cond_dim, max_displacement=cfg.get("max_displacement", 8.0))

    def forward(self, lat, aux, times, valid, t_ego, z_c):
        Ln, K, Cl, H, W = lat.shape
        HW = H * W
        valid = valid.bool()
        x = torch.cat([lat, aux], dim=2).permute(0, 1, 3, 4, 2).reshape(Ln, K, HW, Cl + 2).float()
        gaps, t_last = physical_gaps(times.float(), valid, self.period)
        zc = self.cond(z_c.float())
        h = x.new_zeros(Ln * HW, self.cell.hidden_size)
        for k in range(K):
            inp = self.inp(x[:, k]) + (self.gap_enc(gaps[:, k]) + zc)[:, None, :]
            h_new = self.cell(inp.reshape(Ln * HW, -1), h)
            m = valid[:, k].float().repeat_interleave(HW)[:, None]
            h = m * h_new + (1 - m) * h
        horizon = (t_ego.float() - t_last).clamp_min(0.0)
        q = (self.gap_enc(horizon) + zc).repeat_interleave(HW, dim=0)
        h = self.cell(q, h)
        feat = h.view(Ln, H, W, -1)
        u_fwd = self.out(feat).permute(0, 3, 1, 2)
        last = last_valid_index(valid)
        aux_last = aux[torch.arange(Ln, device=aux.device), last].float()
        offsets, omega = self.warp_head(torch.cat([feat.permute(0, 3, 1, 2), aux_last], dim=1), z_c)
        return omega * flow_warp(u_fwd, offsets) + (1 - omega) * u_fwd, omega, offsets


class AttentionPredictor(nn.Module):
    """Per-location temporal attention: a horizon-aware query attends over the buffered entries."""

    def __init__(self, cfg, latent_channels, cond_dim, frame_period=0.1):
        super().__init__()
        d = int(cfg.get("d_model", 128))
        self.inp = nn.Linear(latent_channels + 2, d)
        self.time_enc = TimeEncoding(d)
        self.cond = nn.Linear(cond_dim, d)
        self.query = nn.Parameter(torch.zeros(d))
        self.layers = nn.ModuleList(
            [nn.TransformerDecoderLayer(d, int(cfg.get("heads", 4)), 2 * d, dropout=0.0, batch_first=True)
             for _ in range(int(cfg.get("num_layers", 2)))]
        )
        self.out = nn.Linear(d, latent_channels)
        self.warp_head = WarpHead(d + 2, cond_dim, max_displacement=cfg.get("max_displacement", 8.0))

    def forward(self, lat, aux, times, valid, t_ego, z_c):
        Ln, K, Cl, H, W = lat.shape
        HW = H * W
        valid = valid.bool()
        x = torch.cat([lat, aux], dim=2).permute(0, 1, 3, 4, 2).reshape(Ln, K, HW, Cl + 2).float()
        rel = times.float() - t_ego.float()[:, None]
        mem = self.inp(x) + self.time_enc(rel)[:, :, None, :]
        mem = mem.permute(0, 2, 1, 3).reshape(Ln * HW, K, -1)
        pad = (~valid).repeat_interleave(HW, dim=0)
        q = self.query[None] + self.time_enc(torch.zeros_like(t_ego.float())) + self.cond(z_c.float())
        q = q.repeat_interleave(HW, dim=0)[:, None, :]
        for layer in self.layers:
            q = layer(q, mem, memory_key_padding_mask=pad)
        feat = q[:, 0].view(Ln, H, W, -1)
        u_fwd = self.out(feat).permute(0, 3, 1, 2)
        last = last_valid_index(valid)
        aux_last = aux[torch.arange(Ln, device=aux.device), last].float()
        offsets, omega = self.warp_head(torch.cat([feat.permute(0, 3, 1, 2), aux_last], dim=1), z_c)
        return omega * flow_warp(u_fwd, offsets) + (1 - omega) * u_fwd, omega, offsets


class FlowPredictor(nn.Module):
    """BEV motion field from the two latest entries, extrapolated linearly over the horizon."""

    def __init__(self, cfg, latent_channels, cond_dim, frame_period=0.1):
        super().__init__()
        self.period = float(frame_period)
        self.flow_net = nn.Sequential(
            ConvNormAct(2 * latent_channels + 1, 64, 3), ConvNormAct(64, 64, 3), nn.Conv2d(64, 2, 3, padding=1)
        )
        nn.init.zeros_(self.flow_net[-1].weight)
        nn.init.zeros_(self.flow_net[-1].bias)

    def forward(self, lat, aux, times, valid, t_ego, z_c):
        Ln, K, Cl, H, W = lat.shape
        valid = valid.bool()
        idx = torch.arange(Ln, device=lat.device)
        last = last_valid_index(valid)
        prev_valid = valid.clone()
        prev_valid[idx, last] = False
        has_prev = prev_valid.any(dim=1)
        prev = torch.where(has_prev, last_valid_index(prev_valid), last)
        u_last, u_prev = lat[idx, last].float(), lat[idx, prev].float()
        t_last, t_prev = times[idx, last].float(), times[idx, prev].float()
        dt = (t_last - t_prev).clamp_min(self.period)
        dt_map = (dt / self.period)[:, None, None, None].expand(-1, 1, H, W)
        velocity = self.flow_net(torch.cat([u_last, u_prev, dt_map], dim=1)).float() / self.period
        velocity = velocity * has_prev[:, None, None, None].float()
        horizon = (t_ego.float() - t_last).clamp_min(0.0)
        offsets = -velocity * horizon[:, None, None, None]
        omega = torch.ones_like(u_last[:, :1])
        return flow_warp(u_last, offsets), omega, offsets


def build_predictor(cfg, latent_channels, cond_dim, frame_period=0.1):
    kind = cfg.get("type", "ssm")
    if kind == "ssm":
        return SSMPredictor(cfg, latent_channels, cond_dim, frame_period)
    if kind == "ssm_uniform":
        cfg = dict(cfg)
        cfg["physical_dt"] = False
        return SSMPredictor(cfg, latent_channels, cond_dim, frame_period)
    if kind == "gru":
        return GRUPredictor(cfg, latent_channels, cond_dim, frame_period)
    if kind == "attention":
        return AttentionPredictor(cfg, latent_channels, cond_dim, frame_period)
    if kind == "flow":
        return FlowPredictor(cfg, latent_channels, cond_dim, frame_period)
    raise ValueError(f"unknown predictor type: {kind}")
