"""Low-dimensional message latent: a two-layer convolutional encoder and its decoder."""

import torch.nn as nn

from .common import group_norm


class LatentCodec(nn.Module):
    def __init__(self, feat_channels=64, latent_channels=16, hidden=64):
        super().__init__()
        self.encoder = nn.Sequential(
            nn.Conv2d(feat_channels, hidden, 3, padding=1),
            group_norm(hidden),
            nn.SiLU(),
            nn.Conv2d(hidden, latent_channels, 1),
            nn.GroupNorm(1, latent_channels, affine=False),  # keeps latents near unit variance for diffusion
        )
        self.decoder = nn.Sequential(
            nn.Conv2d(latent_channels, hidden, 3, padding=1),
            group_norm(hidden),
            nn.SiLU(),
            nn.Conv2d(hidden, feat_channels, 3, padding=1),
        )

    def encode(self, feat):
        return self.encoder(feat)

    def decode(self, latent):
        return self.decoder(latent)
