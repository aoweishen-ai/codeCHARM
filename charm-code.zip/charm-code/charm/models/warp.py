"""Dense BEV displacement warping with a per-cell validity score."""

import torch
import torch.nn as nn
import torch.nn.functional as F

from .common import ConvNormAct, FiLM


def flow_warp(x, offsets):
    """Bilinearly sample x at p + offsets[p]. offsets: (N, 2, H, W) in cells (dx along W, dy along H)."""
    N, C, H, W = x.shape
    ys, xs = torch.meshgrid(
        torch.arange(H, device=x.device, dtype=torch.float32),
        torch.arange(W, device=x.device, dtype=torch.float32),
        indexing="ij",
    )
    gx = (xs[None] + 0.5 + offsets[:, 0].float()) / W * 2.0 - 1.0
    gy = (ys[None] + 0.5 + offsets[:, 1].float()) / H * 2.0 - 1.0
    grid = torch.stack([gx, gy], dim=-1).to(x.dtype)
    return F.grid_sample(x, grid, mode="bilinear", padding_mode="border", align_corners=False)


class WarpHead(nn.Module):
    """Decodes a displacement field and a validity score from the rolled-forward state."""

    def __init__(self, in_channels, cond_dim, hidden=64, max_displacement=8.0):
        super().__init__()
        self.max_disp = float(max_displacement)
        self.conv1 = ConvNormAct(in_channels, hidden, 3)
        self.film = FiLM(cond_dim, hidden)
        self.conv2 = ConvNormAct(hidden, hidden, 3)
        self.out = nn.Conv2d(hidden, 3, 3, padding=1)
        nn.init.zeros_(self.out.weight)
        nn.init.zeros_(self.out.bias)

    def forward(self, x, z_c):
        h = self.film(self.conv1(x), z_c)
        o = self.out(self.conv2(h)).float()
        offsets = torch.tanh(o[:, :2]) * self.max_disp
        omega = torch.sigmoid(o[:, 2:3])
        return offsets, omega
