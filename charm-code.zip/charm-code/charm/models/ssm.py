"""Spatio-temporal selective state space predictor for latency compensation.

Every BEV location of a collaborator latent is treated as an observation of a continuous-time
linear system. The discretisation step of the temporal recurrence is a learned gain times the
physical gap between consecutive generation timestamps, so irregular arrivals need no resampling,
and an appended zero-input step whose length is the residual horizon rolls the state forward to
the ego timestamp. Temporal scans are interleaved with bidirectional row/column selective scans
over the BEV plane.
"""

import math

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.checkpoint import checkpoint

from .common import FiLM, TimeEncoding, inverse_softplus
from .warp import WarpHead, flow_warp

try:  # optional fused CUDA kernel
    from mamba_ssm.ops.selective_scan_interface import selective_scan_fn as _mamba_selective_scan

    _HAS_MAMBA = True
except Exception:  # pragma: no cover
    _mamba_selective_scan = None
    _HAS_MAMBA = False


# --------------------------------------------------------------------------------- scans
def selective_scan_ref(u, delta, A, B, C, D=None):
    """Parallel reference selective scan in log space.

    u, delta: (b, d, l); A: (d, n) negative real; B, C: (b, n, l); D: (d,). Returns (b, d, l).
    h_t = exp(dA_t) h_{t-1} + delta_t B_t u_t, computed as a prefix sum with stable log-cumsum-exp.
    """
    dA = delta.unsqueeze(-1) * A[None, :, None, :]  # (b, d, l, n), <= 0
    dBu = (delta * u).unsqueeze(-1) * B.transpose(1, 2)[:, None]  # (b, d, l, n)
    S = torch.cumsum(dA, dim=2)
    floor = 1e-30
    log_pos = torch.log(dBu.clamp_min(floor)) - S
    log_neg = torch.log((-dBu).clamp_min(floor)) - S
    h = torch.exp(S + torch.logcumsumexp(log_pos, dim=2)) - torch.exp(S + torch.logcumsumexp(log_neg, dim=2))
    y = torch.einsum("bdln,bnl->bdl", h, C)
    if D is not None:
        y = y + D[None, :, None] * u
    return y


def selective_scan(u, delta, A, B, C, D=None, delta_softplus=True):
    if _HAS_MAMBA and u.is_cuda:
        return _mamba_selective_scan(
            u.contiguous(), delta.contiguous(), A.contiguous(), B.contiguous(), C.contiguous(),
            D=D, z=None, delta_bias=None, delta_softplus=delta_softplus,
        )
    if delta_softplus:
        delta = F.softplus(delta)
    return selective_scan_ref(u, delta, A, B, C, D)


def _dt_linear(dt_rank, d_inner, dt_min=1e-3, dt_max=1e-1):
    lin = nn.Linear(dt_rank, d_inner, bias=True)
    nn.init.uniform_(lin.weight, -dt_rank ** -0.5, dt_rank ** -0.5)
    dt = torch.exp(torch.rand(d_inner) * (math.log(dt_max) - math.log(dt_min)) + math.log(dt_min))
    with torch.no_grad():
        lin.bias.copy_(inverse_softplus(dt))
    return lin


def physical_gaps(times, valid, period):
    """Gap to the previous valid entry (nominal period for the first one); 0 for invalid entries."""
    sentinel = -1e9
    tv = torch.where(valid, times, torch.full_like(times, sentinel))
    run = torch.cummax(tv, dim=1).values
    prev = torch.cat([torch.full_like(run[:, :1], sentinel), run[:, :-1]], dim=1)
    gaps = torch.where(prev > sentinel / 2, times - prev, torch.full_like(times, period))
    gaps = gaps.clamp_min(0.0) * valid.float()
    return gaps, run[:, -1]


def last_valid_index(valid):
    K = valid.shape[1]
    return (valid.long() * torch.arange(1, K + 1, device=valid.device)).argmax(dim=1)


# --------------------------------------------------------------------------------- layers
class TemporalSelectiveScan(nn.Module):
    """Selective SSM over the short, irregular history of one BEV location.

    The step of each entry is softplus(learned) * physical gap. Zero-order-hold discretisation:
    A_bar = exp(delta A), B_bar = A^{-1}(exp(delta A) - I) B (exact for diagonal A).
    """

    def __init__(self, d_model, d_state=16, expand=2, cond_dim=64, dt_rank=None,
                 gain_min=0.5, gain_max=5.0):
        super().__init__()
        self.d_inner = expand * d_model
        self.d_state = d_state
        self.dt_rank = dt_rank or math.ceil(d_model / 16)
        self.in_proj = nn.Linear(d_model, 2 * self.d_inner, bias=False)
        self.cond = nn.Linear(cond_dim, self.d_inner)
        self.x_proj = nn.Linear(self.d_inner, self.dt_rank + 2 * d_state, bias=False)
        self.dt_proj = nn.Linear(self.dt_rank, self.d_inner, bias=True)
        gain = torch.exp(torch.rand(self.d_inner) * (math.log(gain_max) - math.log(gain_min)) + math.log(gain_min))
        with torch.no_grad():
            self.dt_proj.bias.copy_(inverse_softplus(gain))
        A = torch.arange(1, d_state + 1, dtype=torch.float32).repeat(self.d_inner, 1)
        self.A_log = nn.Parameter(torch.log(A))
        self.D = nn.Parameter(torch.ones(self.d_inner))
        self.out_proj = nn.Linear(self.d_inner, d_model, bias=False)

    def forward(self, x, gaps, inject, active, z_c):
        """x (N, L, d); gaps/inject/active (N, L); z_c (N, dc). Returns y (N, L, d), final state (N, d_inner, n)."""
        with torch.autocast(device_type=x.device.type, enabled=False):
            x = x.float()
            xs, z = self.in_proj(x).chunk(2, dim=-1)
            xs = F.silu(xs)
            sel = self.x_proj(xs + self.cond(z_c.float())[:, None, :])
            dt, Bm, Cm = sel.split([self.dt_rank, self.d_state, self.d_state], dim=-1)
            gain = F.softplus(self.dt_proj(dt))  # learned gain
            delta = gain * (gaps * active).unsqueeze(-1)  # physical step
            A = -torch.exp(self.A_log.float())  # (d, n)
            N, L, _ = x.shape
            h = x.new_zeros(N, self.d_inner, self.d_state)
            ys = []
            for l in range(L):
                dA = torch.exp(delta[:, l, :, None] * A)
                dB = (dA - 1.0) / A * Bm[:, l, None, :]
                x_in = xs[:, l] * inject[:, l, None]
                h = dA * h + dB * x_in[..., None]
                ys.append((h * Cm[:, l, None, :]).sum(-1) + self.D * x_in)
            y = torch.stack(ys, dim=1) * F.silu(z)
            return self.out_proj(y), h


class SpatialSelectiveScan(nn.Module):
    """Selective scans over the BEV plane in row-major and column-major order, both directions."""

    def __init__(self, d_model, d_state=16, expand=2, cond_dim=64, dt_rank=None, num_dirs=4):
        super().__init__()
        self.d_inner = expand * d_model
        self.d_state = d_state
        self.dt_rank = dt_rank or math.ceil(d_model / 16)
        self.num_dirs = num_dirs
        self.in_proj = nn.Linear(d_model, 2 * self.d_inner, bias=False)
        self.dwconv = nn.Conv2d(self.d_inner, self.d_inner, 3, padding=1, groups=self.d_inner)
        self.cond = nn.Linear(cond_dim, self.d_inner)
        self.x_proj = nn.ModuleList(
            [nn.Linear(self.d_inner, self.dt_rank + 2 * d_state, bias=False) for _ in range(num_dirs)]
        )
        self.dt_proj = nn.ModuleList([_dt_linear(self.dt_rank, self.d_inner) for _ in range(num_dirs)])
        A = torch.arange(1, d_state + 1, dtype=torch.float32).repeat(num_dirs, self.d_inner, 1)
        self.A_log = nn.Parameter(torch.log(A))
        self.D = nn.Parameter(torch.ones(num_dirs, self.d_inner))
        self.out_norm = nn.LayerNorm(self.d_inner)
        self.out_proj = nn.Linear(self.d_inner, d_model, bias=False)

    def forward(self, x, z_c):
        """x (N, H, W, d), z_c (N, dc) -> (N, H, W, d)."""
        N, H, W, _ = x.shape
        with torch.autocast(device_type=x.device.type, enabled=False):
            x = x.float()
            xs, z = self.in_proj(x).chunk(2, dim=-1)
            xs = F.silu(self.dwconv(xs.permute(0, 3, 1, 2)))
            xs = xs + self.cond(z_c.float())[:, :, None, None]
            row = xs.flatten(2)
            col = xs.transpose(2, 3).flatten(2)
            seqs = [row, col, row.flip(-1), col.flip(-1)][: self.num_dirs]
            total = 0.0
            for k, seq in enumerate(seqs):
                dbc = self.x_proj[k](seq.transpose(1, 2))
                dt, Bm, Cm = dbc.split([self.dt_rank, self.d_state, self.d_state], dim=-1)
                delta = self.dt_proj[k](dt).transpose(1, 2)
                A = -torch.exp(self.A_log[k])
                y = selective_scan(
                    seq.contiguous(), delta.contiguous(), A, Bm.transpose(1, 2).contiguous(),
                    Cm.transpose(1, 2).contiguous(), self.D[k], delta_softplus=True,
                )
                if k == 0:
                    y = y.view(N, -1, H, W)
                elif k == 1:
                    y = y.view(N, -1, W, H).transpose(2, 3)
                elif k == 2:
                    y = y.flip(-1).view(N, -1, H, W)
                else:
                    y = y.flip(-1).view(N, -1, W, H).transpose(2, 3)
                total = total + y
            y = self.out_norm(total.permute(0, 2, 3, 1)) * F.silu(z)
            return self.out_proj(y)


class GatedMLP(nn.Module):
    def __init__(self, d_model, ratio=2):
        super().__init__()
        self.fc1 = nn.Linear(d_model, 2 * ratio * d_model)
        self.fc2 = nn.Linear(ratio * d_model, d_model)

    def forward(self, x):
        a, b = self.fc1(x).chunk(2, dim=-1)
        return self.fc2(F.silu(a) * b)


class CharmBlock(nn.Module):
    """Temporal scan, bidirectional spatial scan and gated MLP, each with a residual connection
    and channel-conditioned affine modulation."""

    def __init__(self, d_model, d_state, expand, cond_dim, spatial_stride=1):
        super().__init__()
        self.norm1 = nn.LayerNorm(d_model)
        self.film1 = FiLM(cond_dim, d_model)
        self.temporal = TemporalSelectiveScan(d_model, d_state, expand, cond_dim)
        self.norm2 = nn.LayerNorm(d_model)
        self.film2 = FiLM(cond_dim, d_model)
        self.spatial = SpatialSelectiveScan(d_model, d_state, expand, cond_dim)
        self.norm3 = nn.LayerNorm(d_model)
        self.film3 = FiLM(cond_dim, d_model)
        self.mlp = GatedMLP(d_model)
        self.spatial_stride = int(spatial_stride)

    def forward(self, x, gaps, inject, active, z_c):
        Bn, L, H, W, d = x.shape
        HW = H * W
        t_in = self.film1(self.norm1(x), z_c, channel_last=True)
        t_seq = t_in.permute(0, 2, 3, 1, 4).reshape(Bn * HW, L, d)
        y, h = self.temporal(
            t_seq,
            gaps.repeat_interleave(HW, dim=0),
            inject.repeat_interleave(HW, dim=0),
            active.repeat_interleave(HW, dim=0),
            z_c.repeat_interleave(HW, dim=0),
        )
        x = x + y.view(Bn, H, W, L, d).permute(0, 3, 1, 2, 4).to(x.dtype)

        s_in = self.film2(self.norm2(x), z_c, channel_last=True).reshape(Bn * L, H, W, d)
        z_rep = z_c.repeat_interleave(L, dim=0)
        if self.spatial_stride > 1:
            s = self.spatial_stride
            s_low = F.avg_pool2d(s_in.permute(0, 3, 1, 2), s).permute(0, 2, 3, 1)
            y = self.spatial(s_low, z_rep).permute(0, 3, 1, 2)
            y = F.interpolate(y, size=(H, W), mode="bilinear", align_corners=False).permute(0, 2, 3, 1)
        else:
            y = self.spatial(s_in, z_rep)
        x = x + y.reshape(Bn, L, H, W, d).to(x.dtype)
        x = x + self.mlp(self.film3(self.norm3(x), z_c, channel_last=True))
        return x, h


# --------------------------------------------------------------------------------- predictor
class SSMPredictor(nn.Module):
    """Rolls a collaborator's buffered latents forward to the ego timestamp and warps them."""

    def __init__(self, cfg, latent_channels, cond_dim, frame_period=0.1):
        super().__init__()
        d = int(cfg.get("d_model", 128))
        n = int(cfg.get("d_state", 16))
        e = int(cfg.get("expand", 2))
        self.period = float(frame_period)
        self.physical_dt = bool(cfg.get("physical_dt", True))
        self.use_checkpoint = bool(cfg.get("checkpoint", True))
        self.in_proj = nn.Linear(latent_channels + 2, d)
        self.query = nn.Parameter(torch.zeros(d))
        self.horizon_enc = TimeEncoding(d)
        self.blocks = nn.ModuleList(
            [CharmBlock(d, n, e, cond_dim, cfg.get("spatial_stride", 1)) for _ in range(int(cfg.get("num_blocks", 4)))]
        )
        self.norm_out = nn.LayerNorm(d)
        self.state_weight = nn.Parameter(torch.full((e * d, n), 1.0 / n))
        self.state_proj = nn.Linear(e * d, d)
        self.readout = nn.Linear(d, latent_channels)
        self.g_phi = nn.Sequential(nn.Linear(d, d), nn.SiLU(), nn.Linear(d, latent_channels))
        self.warp_head = WarpHead(2 * d + 2, cond_dim, max_displacement=cfg.get("max_displacement", 8.0))

    def forward(self, lat, aux, times, valid, t_ego, z_c):
        """lat (L, K, Cl, H, W) oldest first; aux (L, K, 2, H, W) = [received mask, dispersion];
        times (L, K) generation times; valid (L, K); t_ego (L,); z_c (L, dc)."""
        Ln, K, Cl, H, W = lat.shape
        valid = valid.bool()
        x = self.in_proj(torch.cat([lat, aux], dim=2).permute(0, 1, 3, 4, 2).float())
        x = x * valid[:, :, None, None, None].float()
        gaps, t_last = physical_gaps(times.float(), valid, self.period)
        horizon = (t_ego.float() - t_last).clamp_min(0.0)
        if not self.physical_dt:
            gaps = valid.float() * self.period
            horizon = torch.full_like(horizon, self.period)
        q = (self.query[None] + self.horizon_enc(horizon))[:, None, None, None, :].expand(Ln, 1, H, W, -1)
        x = torch.cat([x, q.to(x.dtype)], dim=1)
        g = torch.cat([gaps, horizon[:, None]], dim=1)
        inject = torch.cat([valid.float(), torch.zeros_like(horizon)[:, None]], dim=1)
        active = torch.cat([valid.float(), torch.ones_like(horizon)[:, None]], dim=1)

        h_te = None
        for blk in self.blocks:
            if self.use_checkpoint and self.training:
                x, h_te = checkpoint(blk, x, g, inject, active, z_c, use_reentrant=False)
            else:
                x, h_te = blk(x, g, inject, active, z_c)

        q_out = self.norm_out(x[:, -1])  # (L, H, W, d)
        h_feat = self.state_proj((h_te * self.state_weight).sum(-1)).view(Ln, H, W, -1)
        u_fwd = (self.readout(q_out) + self.g_phi(h_feat)).permute(0, 3, 1, 2)

        last = last_valid_index(valid)
        aux_last = aux[torch.arange(Ln, device=aux.device), last]
        warp_in = torch.cat([q_out.permute(0, 3, 1, 2), h_feat.permute(0, 3, 1, 2), aux_last.to(q_out.dtype)], dim=1)
        offsets, omega = self.warp_head(warp_in, z_c)
        u_hat = omega * flow_warp(u_fwd, offsets) + (1 - omega) * u_fwd
        return u_hat, omega, offsets
