"""Streaming deployment of CHARM.

``OnlineSender`` turns sensor data into a packetised token message. ``OnlineReceiver`` keeps,
for every collaborator, a link monitor and an asynchronous buffer of restored latents; each ego
frame it restores only the newly arrived messages, re-aligns the buffer to the current ego pose,
rolls it forward to the ego timestamp and fuses.
"""

from collections import defaultdict, deque

import numpy as np
import torch

from ..channel.estimator import LinkMonitor
from ..models.message import group_view
from ..utils.geometry import warp_bev


def _as_batch(sensors, prefix, device):
    batch = {}
    for key, value in sensors.items():
        if key in ("world_T", "timestamp"):
            continue
        t = value if torch.is_tensor(value) else torch.as_tensor(np.asarray(value))
        batch[prefix + key] = t.unsqueeze(0).to(device)
    return batch


class OnlineSender:
    def __init__(self, model, device):
        self.model = model.eval()
        self.device = device
        self.seq = 0

    @torch.no_grad()
    def build_message(self, sensors, timestamp, world_T, channel_scalars, budget_bytes):
        """sensors: camera {"imgs", "intr", "cam2agent"} or lidar {"points", "num_points"} for one frame."""
        m = self.model
        batch = _as_batch(sensors, "x_", self.device)
        feats, _, _ = m._encode(batch, "x_", torch.ones(1, dtype=torch.bool, device=self.device))
        u = m.codec.encode(feats).float()
        conf = m.head.confidence(feats)
        z = m._embed_channel(torch.as_tensor(channel_scalars, device=self.device).float()[None])
        budget = torch.tensor([float(budget_bytes)], device=self.device)
        msg = m.messenger(u, conf, z, budget)
        groups = group_view(msg["u"], m.group_size)[0]
        sent = msg["sent"][0].cpu().numpy()
        levels = msg["level"][0].cpu().numpy()
        packets = []
        for g in m.packet_order:
            if not sent[g]:
                continue
            packets.append({
                "seq": self.seq,
                "group": int(g),
                "bits": int(m.messenger.levels[int(levels[g]) - 1]),
                # dequantised values; an on-wire encoding carries the integer codes and the group range
                "payload": groups[g].detach().cpu(),
            })
            self.seq = (self.seq + 1) % 65536
        return {
            "timestamp": float(timestamp),
            "pose": np.asarray(world_T, dtype=np.float64),
            "sent_bitmap": sent.copy(),  # small message descriptor replicated in the leading packets
            "packets": packets,
            "bytes": float(msg["bytes"][0]),
        }


class OnlineReceiver:
    def __init__(self, model, device, buffer_size=4, window=20, max_age_s=1.0):
        self.model = model.eval()
        self.device = device
        self.max_age = float(max_age_s)
        self.K = int(buffer_size)
        self.buffers = defaultdict(lambda: deque(maxlen=self.K))
        self.monitors = defaultdict(lambda: LinkMonitor(window))

    def _depacketize(self, msg):
        m = self.model
        s, gh, gw, Cl = m.group_size, m.gh, m.gw, m.latent_ch
        G = gh * gw
        groups = torch.zeros(G, Cl, s, s, device=self.device)
        survived = torch.zeros(G, device=self.device)
        for p in msg["packets"]:
            groups[p["group"]] = p["payload"].to(self.device).float()
            survived[p["group"]] = 1.0
        sent = torch.as_tensor(msg["sent_bitmap"], device=self.device).float()
        u = groups.view(gh, gw, Cl, s, s).permute(2, 0, 3, 1, 4).reshape(1, Cl, gh * s, gw * s)
        return u, m._cells(survived[None]), m._cells(sent[None])

    def _z(self, agent, ego_time, budget):
        scalars = self.monitors[agent].estimate(ego_time, budget)
        return self.model._embed_channel(torch.as_tensor(scalars, device=self.device)[None])

    @torch.no_grad()
    def step(self, ego_sensors, ego_world_T, ego_time, inbox, phy_snr=None, budgets=None):
        """inbox: {agent_id: [message, ...]} that arrived since the previous ego frame."""
        m = self.model
        phy_snr = phy_snr or {}
        budgets = budgets or {}
        grid = m.grid
        ego_world_T = np.asarray(ego_world_T, dtype=np.float64)
        batch = _as_batch(ego_sensors, "ego_", self.device)
        F_e, _, _ = m._encode(batch, "ego_", torch.ones(1, dtype=torch.bool, device=self.device))
        u_e = m.codec.encode(F_e).float()

        for agent, msgs in inbox.items():
            for msg in sorted(msgs, key=lambda x: x["timestamp"]):
                self.monitors[agent].update([p["seq"] for p in msg["packets"]], msg["timestamp"], phy_snr.get(agent))
                if not msg["packets"]:
                    continue
                z = self._z(agent, ego_time, budgets.get(agent, float("inf")))
                u_rx, M, S = self._depacketize(msg)
                T = torch.as_tensor(np.linalg.inv(ego_world_T) @ msg["pose"], device=self.device).float()[None]
                u_rx = warp_bev(u_rx, T, grid)
                M = (warp_bev(M, T, grid, mode="nearest") > 0.5).float()
                S = (warp_bev(S, T, grid, mode="nearest") > 0.5).float()
                gen, var = m.restorer.restore(u_rx, M, u_e, z)
                self.buffers[agent].append({
                    "u": M * u_rx + (1 - M) * gen, "M": M, "S": S, "var": var,
                    "time": msg["timestamp"], "ego_world_T": ego_world_T.copy(),
                })

        F_hats, rels, avails = [], [], []
        for agent, buf in self.buffers.items():
            while buf and ego_time - buf[0]["time"] > self.max_age:
                buf.popleft()
            if not buf:
                continue
            z = self._z(agent, ego_time, budgets.get(agent, float("inf")))
            Cl, H, W = m.latent_ch, grid.H, grid.W
            lat = torch.zeros(1, self.K, Cl, H, W, device=self.device)
            aux = torch.zeros(1, self.K, 2, H, W, device=self.device)
            times = torch.zeros(1, self.K, device=self.device)
            valid = torch.zeros(1, self.K, dtype=torch.bool, device=self.device)
            offset = self.K - len(buf)
            S_last = M_last = var_last = None
            for n, e in enumerate(buf):
                T = torch.as_tensor(np.linalg.inv(ego_world_T) @ e["ego_world_T"], device=self.device).float()[None]
                M = (warp_bev(e["M"], T, grid, mode="nearest") > 0.5).float()
                S_last = (warp_bev(e["S"], T, grid, mode="nearest") > 0.5).float()
                var_last = warp_bev(e["var"], T, grid)
                M_last = M
                lat[0, offset + n] = warp_bev(e["u"], T, grid)[0]
                aux[0, offset + n] = torch.cat([M, torch.log1p(var_last)], dim=1)[0]
                times[0, offset + n] = e["time"] - ego_time
                valid[0, offset + n] = True
            u_hat, omega, _ = m.predictor(lat, aux, times, valid, torch.zeros(1, device=self.device), z)
            horizon = torch.tensor([ego_time - buf[-1]["time"]], device=self.device).clamp_min(0.0)
            F_hats.append(m.codec.decode(u_hat.float()))
            rels.append(m.reliability(z, var_last, omega, horizon, 1 - M_last))
            avails.append(S_last)

        if F_hats:
            F_c = torch.stack(F_hats, dim=1)
            r = torch.stack(rels, dim=1)
            a = torch.stack(avails, dim=1)
        else:
            F_c = F_e.new_zeros(1, 0, *F_e.shape[1:])
            r = F_e.new_zeros(1, 0, 1, *F_e.shape[2:])
            a = r.clone()
        F_fus, _ = m.fusion(F_e, F_c, r, a)
        preds = m.head(F_fus)
        hc = m.det_cfg
        return m.head.decode(
            preds, float(hc.get("score_threshold", 0.05)), float(hc.get("nms_iou", 0.15)), int(hc.get("max_det", 100))
        )[0]
