"""CHARM: channel-adaptive camera V2X BEV perception."""

__version__ = "0.1.0"
