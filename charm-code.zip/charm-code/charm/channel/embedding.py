"""Channel state embedding: random Fourier features of the four channel scalars plus an MLP."""

import math

import torch
import torch.nn as nn


class ChannelEmbedding(nn.Module):
    def __init__(self, dim=64, num_inputs=4, num_frequencies=8, sigma=2.0, hidden=128, seed=0):
        super().__init__()
        gen = torch.Generator().manual_seed(seed)
        self.register_buffer("freqs", torch.randn(num_inputs, num_frequencies, generator=gen) * sigma)
        in_dim = num_inputs * (2 * num_frequencies + 1)
        self.mlp = nn.Sequential(nn.Linear(in_dim, hidden), nn.SiLU(), nn.Linear(hidden, dim))
        self.dim = dim

    def forward(self, scalars):
        scalars = scalars.float()
        angles = 2.0 * math.pi * scalars[..., None] * self.freqs
        feats = torch.cat([scalars[..., None], torch.sin(angles), torch.cos(angles)], dim=-1)
        return self.mlp(feats.flatten(-2))
