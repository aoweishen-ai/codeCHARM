"""Receiver-side channel state estimation from timestamps, sequence numbers and the PHY indicator."""

import math
from collections import deque

import numpy as np

TAU_SCALE_S = 0.5
SNR_SCALE_DB = 30.0
LOG2_BUDGET_SCALE = 20.0
LOG2_BUDGET_CAP = 24.0
SEQ_MODULUS = 65536


def channel_scalars(tau_s, rho, snr_db, budget_bytes):
    """Normalised [delay, loss, SNR, log2 budget] vector consumed by the channel embedding."""
    if budget_bytes is None or not math.isfinite(float(budget_bytes)) or budget_bytes <= 0:
        log2b = LOG2_BUDGET_CAP
    else:
        log2b = min(math.log2(float(budget_bytes)), LOG2_BUDGET_CAP)
    return np.array(
        [min(float(tau_s), 2.0) / TAU_SCALE_S, float(rho), float(snr_db) / SNR_SCALE_DB, log2b / LOG2_BUDGET_SCALE],
        dtype=np.float32,
    )


class LinkMonitor:
    """Online statistics for one collaborator link.

    Every token group carries a two byte sequence number, its generation timestamp and the
    sender pose, so delay and loss can be estimated without a side channel.
    """

    def __init__(self, window=20, default_snr_db=20.0):
        self.window = deque(maxlen=int(window))
        self.last_seq = None
        self.last_gen_time = None
        self.snr_db = float(default_snr_db)

    def update(self, seq_numbers, gen_time, snr_db=None):
        missing = 0
        prev = self.last_seq
        for seq in seq_numbers:
            seq = int(seq) % SEQ_MODULUS
            if prev is not None:
                gap = (seq - prev - 1) % SEQ_MODULUS
                if gap < SEQ_MODULUS // 2:
                    missing += gap
            prev = seq
        if seq_numbers:
            self.last_seq = prev
        self.window.append((len(seq_numbers), missing))
        if gen_time is not None:
            self.last_gen_time = gen_time if self.last_gen_time is None else max(self.last_gen_time, gen_time)
        if snr_db is not None:
            self.snr_db = float(snr_db)

    def loss_rate(self):
        received = sum(r for r, _ in self.window)
        missing = sum(m for _, m in self.window)
        total = received + missing
        return missing / total if total > 0 else 0.0

    def estimate(self, ego_time, budget_bytes):
        tau = 1.0 if self.last_gen_time is None else max(0.0, ego_time - self.last_gen_time)
        return channel_scalars(tau, self.loss_rate(), self.snr_db, budget_bytes)
