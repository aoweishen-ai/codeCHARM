"""Packet-level loss simulation for a sequence of messages sent over one link."""

import numpy as np

from .simulator import GilbertElliottChain


def simulate_link_losses(sent, ge_params, seed, order):
    """Apply a Gilbert-Elliott burst-loss chain to the packets of consecutive messages.

    sent:      (K, G) bool, which token groups each message carries (one group per packet).
    ge_params: [p_gb, p_bg, eps_g, eps_b, initial_bad_state].
    order:     (G,) transmission order of token groups; a Morton order turns bursts into
               spatially contiguous BEV holes.
    Returns (K, G) bool, True where the token group reached the receiver.
    """
    sent = np.asarray(sent, dtype=bool)
    survived = np.zeros_like(sent)
    p_gb, p_bg, eps_g, eps_b, bad = [float(v) for v in ge_params]
    if p_gb + eps_g + eps_b <= 0:
        return sent.copy()
    rng = np.random.default_rng(int(seed))
    chain = GilbertElliottChain(p_gb, p_bg, eps_g, eps_b, rng, bad=bool(bad > 0.5))
    for k in range(sent.shape[0]):
        groups = order[sent[k][order]]
        if groups.size == 0:
            continue
        lost = chain.sample(groups.size)
        survived[k, groups[~lost]] = True
    return survived
