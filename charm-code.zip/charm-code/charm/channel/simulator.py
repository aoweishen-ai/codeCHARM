"""Joint channel impairment model: shifted Gamma delay, Gilbert-Elliott burst loss,
per-link byte budget and planar pose noise."""

import math
from dataclasses import dataclass, replace

import numpy as np

UNCONSTRAINED = float("inf")


def stationary_loss_rate(p_gb, p_bg, eps_g, eps_b):
    """Long-run packet loss rate of a two-state Gilbert-Elliott chain."""
    denom = p_gb + p_bg
    if denom <= 0:
        return float(eps_g)
    return float((p_gb * eps_b + p_bg * eps_g) / denom)


def calibrate_p_gb(target, p_bg, eps_g, eps_b):
    """Good-to-bad transition probability that yields a desired stationary loss rate."""
    if target <= eps_g:
        return 0.0
    if target >= eps_b:
        raise ValueError(f"target loss {target} must be below the bad-state error rate {eps_b}")
    return float(p_bg * (target - eps_g) / (eps_b - target))


@dataclass(frozen=True)
class ChannelParams:
    tau0_ms: float = 50.0
    gamma_shape: float = 2.0
    gamma_scale_ms: float = 75.0
    p_gb: float = 0.08
    p_bg: float = 0.35
    eps_g: float = 0.01
    eps_b: float = 0.6
    budget_bytes: float = 2.0 ** 16
    sigma_t: float = 0.2
    sigma_r_deg: float = 0.2
    snr_good_db: float = 22.0
    snr_bad_db: float = 6.0
    snr_std_db: float = 2.0

    @property
    def mean_delay_ms(self):
        return self.tau0_ms + self.gamma_shape * self.gamma_scale_ms

    @property
    def mean_loss(self):
        return stationary_loss_rate(self.p_gb, self.p_bg, self.eps_g, self.eps_b)

    def with_mean_delay(self, mean_ms):
        """Rescale the shifted Gamma law so that its mean equals ``mean_ms`` while keeping its shape."""
        mean_ms = float(mean_ms)
        if mean_ms <= 0:
            return replace(self, tau0_ms=0.0, gamma_scale_ms=0.0)
        base = self.mean_delay_ms
        if base <= 0:
            return replace(self, tau0_ms=mean_ms, gamma_scale_ms=0.0)
        ratio = mean_ms / base
        return replace(self, tau0_ms=self.tau0_ms * ratio, gamma_scale_ms=self.gamma_scale_ms * ratio)

    def with_mean_loss(self, rho):
        """Re-calibrate the Gilbert-Elliott chain to a target stationary loss rate."""
        rho = float(rho)
        if rho <= 0:
            return replace(self, p_gb=0.0, eps_g=0.0, eps_b=0.0)
        p_bg = self.p_bg if self.p_bg > 0 else 0.35
        eps_b = max(self.eps_b, min(0.99, rho + 0.2))
        eps_g = min(self.eps_g if self.eps_g > 0 else 0.01, 0.5 * rho)
        p_gb = calibrate_p_gb(rho, p_bg, eps_g, eps_b)
        return replace(self, p_gb=p_gb, p_bg=p_bg, eps_g=eps_g, eps_b=eps_b)

    def with_budget(self, budget_bytes):
        budget = UNCONSTRAINED if budget_bytes is None else float(budget_bytes)
        return replace(self, budget_bytes=budget)

    def with_pose_noise(self, sigma_t, sigma_r_deg):
        return replace(self, sigma_t=float(sigma_t), sigma_r_deg=float(sigma_r_deg))

    @classmethod
    def ideal(cls):
        return cls(
            tau0_ms=0.0, gamma_scale_ms=0.0, p_gb=0.0, eps_g=0.0, eps_b=0.0,
            budget_bytes=UNCONSTRAINED, sigma_t=0.0, sigma_r_deg=0.0,
        )

    @classmethod
    def from_dict(cls, cfg):
        cfg = dict(cfg or {})
        target = cfg.pop("target_mean_loss", None)
        budget = cfg.pop("budget_bytes", 2.0 ** 16)
        known = {f for f in cls.__dataclass_fields__}
        params = cls(**{k: float(v) for k, v in cfg.items() if k in known})
        params = params.with_budget(budget)
        if target is not None:
            params = params.with_mean_loss(target)
        return params


class GilbertElliottChain:
    """Two-state Markov burst-loss channel evaluated packet by packet."""

    def __init__(self, p_gb, p_bg, eps_g, eps_b, rng, bad=None):
        self.p_gb, self.p_bg = float(p_gb), float(p_bg)
        self.eps_g, self.eps_b = float(eps_g), float(eps_b)
        self.rng = rng
        if bad is None:
            bad = bool(rng.random() < self.stationary_bad)
        self.bad = bool(bad)

    @property
    def stationary_bad(self):
        denom = self.p_gb + self.p_bg
        return self.p_gb / denom if denom > 0 else 0.0

    def step(self):
        eps = self.eps_b if self.bad else self.eps_g
        lost = bool(self.rng.random() < eps)
        if self.bad:
            if self.rng.random() < self.p_bg:
                self.bad = False
        elif self.rng.random() < self.p_gb:
            self.bad = True
        return lost

    def sample(self, n):
        return np.array([self.step() for _ in range(int(n))], dtype=bool)


def sample_delays_s(params, n, rng):
    delays = np.full(int(n), params.tau0_ms, dtype=np.float64)
    if params.gamma_scale_ms > 0 and params.gamma_shape > 0:
        delays = delays + rng.gamma(params.gamma_shape, params.gamma_scale_ms, size=int(n))
    return delays / 1000.0


class ChannelSampler:
    """Draws per-link channel realisations.

    mode = "ideal":      no delay, no loss, unconstrained budget, no pose noise.
    mode = "realistic":  the nominal parameters are used as is.
    mode = "randomized": domain randomisation over the impairment space, scaled by a curriculum factor.
    """

    def __init__(self, nominal, randomization=None, mode="realistic", buffer_size=4,
                 rho_window=20, packets_per_frame=64, max_tau_s=1.0):
        self.nominal = nominal
        self.randomization = dict(randomization or {})
        self.mode = mode
        self.buffer_size = int(buffer_size)
        self.rho_window = int(rho_window)
        self.packets_per_frame = int(packets_per_frame)
        self.max_tau_s = float(max_tau_s)
        self.curriculum_scale = 1.0
        self.tail = True

    def set_curriculum(self, scale, tail=True):
        self.curriculum_scale = float(np.clip(scale, 0.0, 1.0))
        self.tail = bool(tail)

    def draw_params(self, rng):
        if self.mode == "ideal":
            return ChannelParams.ideal()
        if self.mode == "realistic":
            return self.nominal
        scale = self.curriculum_scale
        if scale <= 0:
            return ChannelParams.ideal()
        rnd = self.randomization
        tail = float(rnd.get("tail_factor", 1.0)) if self.tail else 1.0
        mean_delay = rng.uniform(0.0, scale * float(rnd.get("max_mean_delay_ms", 500.0)) * tail)
        loss = rng.uniform(0.0, min(0.9, scale * float(rnd.get("max_loss", 0.5)) * tail))
        params = self.nominal.with_mean_delay(mean_delay).with_mean_loss(loss)
        lo, hi = rnd.get("log2_budget_range", [10.0, 20.0])
        if rng.random() < scale * float(rnd.get("budget_prob", 0.9)):
            budget = 2.0 ** rng.uniform(lo, hi)
        else:
            budget = UNCONSTRAINED
        return replace(
            params,
            budget_bytes=budget,
            sigma_t=self.nominal.sigma_t * scale,
            sigma_r_deg=self.nominal.sigma_r_deg * scale,
        )

    def sample_link(self, gen_times, rng, params=None):
        """Simulate one collaborator link.

        gen_times: ascending generation times of candidate collaborator frames, expressed relative
        to the ego timestamp (seconds, <= 0). Returns which frames reached the ego agent before
        fusion, receiver-side channel estimates and the burst-loss chain state that continues into
        the packet-level simulation of the selected messages.
        """
        p = params or self.draw_params(rng)
        gen_times = np.asarray(gen_times, dtype=np.float64)
        n = len(gen_times)
        delays = sample_delays_s(p, n, rng)
        received = gen_times + delays <= 1e-6
        idx = np.nonzero(received)[0]
        selected = idx[-self.buffer_size:].tolist()

        chain = GilbertElliottChain(p.p_gb, p.p_bg, p.eps_g, p.eps_b, rng)
        window = chain.sample(self.rho_window * self.packets_per_frame) if p.p_gb + p.eps_g + p.eps_b > 0 else np.zeros(0, bool)
        rho_hat = float(window.mean()) if window.size else 0.0
        snr = (p.snr_bad_db if chain.bad else p.snr_good_db) + rng.normal(0.0, p.snr_std_db)
        tau_hat = float(-gen_times[selected[-1]]) if selected else self.max_tau_s

        return {
            "selected": selected,
            "delays": delays,
            "tau_hat": min(tau_hat, self.max_tau_s),
            "rho_hat": rho_hat,
            "snr_db": float(snr),
            "budget": float(p.budget_bytes),
            "ge": np.array([p.p_gb, p.p_bg, p.eps_g, p.eps_b, float(chain.bad)], dtype=np.float32),
            "seed": int(rng.integers(0, 2 ** 31 - 1)),
            "sigma_t": float(p.sigma_t),
            "sigma_r_deg": float(p.sigma_r_deg),
            "params": p,
        }


def is_unconstrained(budget):
    return budget is None or not math.isfinite(float(budget))
