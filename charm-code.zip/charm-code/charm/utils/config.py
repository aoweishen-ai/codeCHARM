"""YAML configuration loading with single inheritance and dotted CLI overrides."""

import copy
import os

import yaml


def _deep_merge(base, override):
    out = copy.deepcopy(base)
    for key, value in override.items():
        if isinstance(value, dict) and isinstance(out.get(key), dict):
            out[key] = _deep_merge(out[key], value)
        else:
            out[key] = copy.deepcopy(value)
    return out


def _set_by_path(cfg, dotted, value):
    keys = dotted.split(".")
    node = cfg
    for key in keys[:-1]:
        node = node.setdefault(key, {})
    node[keys[-1]] = value


def load_config(path, overrides=None):
    """Load a YAML config. A top-level ``_base_`` key names a parent config.

    ``overrides`` is a list of ``a.b.c=value`` strings; values are parsed as YAML.
    """
    with open(path, "r") as f:
        cfg = yaml.safe_load(f) or {}
    base = cfg.pop("_base_", None)
    if base is not None:
        base_path = base if os.path.isabs(base) else os.path.join(os.path.dirname(path), base)
        cfg = _deep_merge(load_config(base_path), cfg)
    for item in overrides or []:
        key, value = item.split("=", 1)
        _set_by_path(cfg, key.strip(), yaml.safe_load(value))
    return cfg
