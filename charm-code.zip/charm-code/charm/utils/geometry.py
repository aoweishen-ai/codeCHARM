"""Rigid-body helpers, BEV grid definition and BEV warping."""

import math

import numpy as np
import torch
import torch.nn.functional as F

# Maps a point expressed in an OpenCV camera frame (x right, y down, z forward)
# to the Unreal/CARLA camera frame (x forward, y right, z up).
CV_TO_UE = np.array(
    [[0.0, 0.0, 1.0, 0.0],
     [1.0, 0.0, 0.0, 0.0],
     [0.0, -1.0, 0.0, 0.0],
     [0.0, 0.0, 0.0, 1.0]],
    dtype=np.float64,
)


def pose_to_matrix(pose):
    """Convert [x, y, z, roll, yaw, pitch] (metres, degrees; CARLA convention) to world_T_x."""
    x, y, z, roll, yaw, pitch = [float(v) for v in pose[:6]]
    c_y, s_y = math.cos(math.radians(yaw)), math.sin(math.radians(yaw))
    c_r, s_r = math.cos(math.radians(roll)), math.sin(math.radians(roll))
    c_p, s_p = math.cos(math.radians(pitch)), math.sin(math.radians(pitch))
    m = np.identity(4)
    m[0, 3], m[1, 3], m[2, 3] = x, y, z
    m[0, 0] = c_p * c_y
    m[0, 1] = c_y * s_p * s_r - s_y * c_r
    m[0, 2] = -c_y * s_p * c_r - s_y * s_r
    m[1, 0] = s_y * c_p
    m[1, 1] = s_y * s_p * s_r + c_y * c_r
    m[1, 2] = -s_y * s_p * c_r + c_y * s_r
    m[2, 0] = s_p
    m[2, 1] = -c_p * s_r
    m[2, 2] = c_p * c_r
    return m


def rt_to_matrix(rotation, translation):
    m = np.identity(4)
    m[:3, :3] = np.asarray(rotation, dtype=np.float64).reshape(3, 3)
    m[:3, 3] = np.asarray(translation, dtype=np.float64).reshape(3)
    return m


def yaw_of(matrix):
    return math.atan2(matrix[1, 0], matrix[0, 0])


def perturb_pose_matrix(world_T, sigma_t, sigma_r_deg, rng):
    """Add planar Gaussian noise (x, y, heading) to a 4x4 pose."""
    out = np.array(world_T, dtype=np.float64, copy=True)
    if sigma_t <= 0 and sigma_r_deg <= 0:
        return out
    out[0, 3] += rng.normal(0.0, sigma_t) if sigma_t > 0 else 0.0
    out[1, 3] += rng.normal(0.0, sigma_t) if sigma_t > 0 else 0.0
    dyaw = math.radians(rng.normal(0.0, sigma_r_deg)) if sigma_r_deg > 0 else 0.0
    c, s = math.cos(dyaw), math.sin(dyaw)
    rz = np.array([[c, -s, 0.0], [s, c, 0.0], [0.0, 0.0, 1.0]])
    out[:3, :3] = rz @ out[:3, :3]
    return out


class BEVGrid:
    """Metric BEV grid. Width indexes x, height indexes y; cell centres at (i + 0.5) * res."""

    def __init__(self, x_range, y_range, resolution):
        self.x_min, self.x_max = float(x_range[0]), float(x_range[1])
        self.y_min, self.y_max = float(y_range[0]), float(y_range[1])
        self.res = float(resolution)
        self.W = int(round((self.x_max - self.x_min) / self.res))
        self.H = int(round((self.y_max - self.y_min) / self.res))

    def downsample(self, stride):
        return BEVGrid((self.x_min, self.x_max), (self.y_min, self.y_max), self.res * stride)

    def __repr__(self):
        return f"BEVGrid(x=[{self.x_min},{self.x_max}], y=[{self.y_min},{self.y_max}], res={self.res}, HxW={self.H}x{self.W})"


def bev_sampling_grid(T_dst_from_src, dst, src=None):
    """Sampling grid for ``grid_sample`` that resamples a source-frame BEV map into the destination frame.

    T_dst_from_src: (N, 4, 4) rigid transform mapping source coordinates to destination coordinates.
    """
    src = src or dst
    device = T_dst_from_src.device
    T = T_dst_from_src.double()
    xs = dst.x_min + (torch.arange(dst.W, device=device, dtype=torch.float64) + 0.5) * dst.res
    ys = dst.y_min + (torch.arange(dst.H, device=device, dtype=torch.float64) + 0.5) * dst.res
    gy, gx = torch.meshgrid(ys, xs, indexing="ij")
    pts = torch.stack([gx, gy, torch.ones_like(gx)], dim=-1)  # (H, W, 3)
    T_src_from_dst = torch.linalg.inv(T)
    planar = T_src_from_dst[:, :2][:, :, [0, 1, 3]]  # (N, 2, 3)
    src_xy = torch.einsum("nij,hwj->nhwi", planar, pts)
    u = (src_xy[..., 0] - src.x_min) / (src.x_max - src.x_min) * 2.0 - 1.0
    v = (src_xy[..., 1] - src.y_min) / (src.y_max - src.y_min) * 2.0 - 1.0
    return torch.stack([u, v], dim=-1).float()


def warp_bev(x, T_dst_from_src, dst, src=None, mode="bilinear"):
    """Rigidly warp a BEV tensor (N, C, H, W) from the source frame into the destination frame."""
    if x.shape[0] == 0:
        return x
    grid = bev_sampling_grid(T_dst_from_src, dst, src).to(x.dtype)
    return F.grid_sample(x, grid, mode=mode, padding_mode="zeros", align_corners=False)


def morton_order(gh, gw):
    """Z-order (Morton) traversal of a gh x gw grid of token groups."""

    def spread(v):
        out = 0
        for bit in range(16):
            out |= ((v >> bit) & 1) << (2 * bit)
        return out

    codes = np.array([spread(c) | (spread(r) << 1) for r in range(gh) for c in range(gw)], dtype=np.int64)
    return np.argsort(codes, kind="stable")


def raster_order(gh, gw):
    return np.arange(gh * gw, dtype=np.int64)
