"""Box utilities. Boxes are (x, y, z, l, w, h, yaw) with yaw around +z in radians."""

import numpy as np

try:
    from shapely.geometry import Polygon
except ImportError:  # pragma: no cover
    Polygon = None


def boxes_to_bev_corners(boxes):
    boxes = np.asarray(boxes, dtype=np.float64).reshape(-1, 7)
    x, y, l, w, yaw = boxes[:, 0], boxes[:, 1], boxes[:, 3], boxes[:, 4], boxes[:, 6]
    dx = np.array([0.5, 0.5, -0.5, -0.5])
    dy = np.array([0.5, -0.5, -0.5, 0.5])
    cx = l[:, None] * dx[None]
    cy = w[:, None] * dy[None]
    c, s = np.cos(yaw)[:, None], np.sin(yaw)[:, None]
    xs = x[:, None] + cx * c - cy * s
    ys = y[:, None] + cx * s + cy * c
    return np.stack([xs, ys], axis=-1)


def bev_iou_matrix(a, b):
    """Rotated BEV IoU between two box sets, (Na, Nb)."""
    if Polygon is None:
        raise ImportError("shapely is required for rotated IoU")
    a = np.asarray(a).reshape(-1, 7)
    b = np.asarray(b).reshape(-1, 7)
    out = np.zeros((len(a), len(b)), dtype=np.float64)
    if len(a) == 0 or len(b) == 0:
        return out
    pa = [Polygon(c) for c in boxes_to_bev_corners(a)]
    pb = [Polygon(c) for c in boxes_to_bev_corners(b)]
    for i, p in enumerate(pa):
        for j, q in enumerate(pb):
            if not p.intersects(q):
                continue
            inter = p.intersection(q).area
            union = p.area + q.area - inter
            out[i, j] = inter / max(union, 1e-9)
    return out


def nms_bev(boxes, scores, iou_threshold):
    boxes = np.asarray(boxes).reshape(-1, 7)
    scores = np.asarray(scores).reshape(-1)
    if len(boxes) == 0:
        return np.zeros(0, dtype=np.int64)
    order = np.argsort(-scores)
    polys = [Polygon(c) for c in boxes_to_bev_corners(boxes)]
    keep = []
    suppressed = np.zeros(len(boxes), dtype=bool)
    for idx_pos, i in enumerate(order):
        if suppressed[i]:
            continue
        keep.append(i)
        for j in order[idx_pos + 1:]:
            if suppressed[j] or not polys[i].intersects(polys[j]):
                continue
            inter = polys[i].intersection(polys[j]).area
            iou = inter / max(polys[i].area + polys[j].area - inter, 1e-9)
            if iou > iou_threshold:
                suppressed[j] = True
    return np.array(keep, dtype=np.int64)


def filter_boxes_in_range(boxes, x_range, y_range):
    boxes = np.asarray(boxes).reshape(-1, 7)
    keep = (
        (boxes[:, 0] >= x_range[0]) & (boxes[:, 0] <= x_range[1])
        & (boxes[:, 1] >= y_range[0]) & (boxes[:, 1] <= y_range[1])
    )
    return boxes[keep]
