"""Training utilities: seeding, distributed helpers, checkpoints and logging."""

import logging
import os
import random
import sys

import numpy as np
import torch
import torch.distributed as dist


def seed_everything(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


def init_distributed():
    """Initialise torch.distributed when launched with torchrun. Returns (rank, world, local_rank)."""
    if "RANK" in os.environ and "WORLD_SIZE" in os.environ:
        rank = int(os.environ["RANK"])
        world = int(os.environ["WORLD_SIZE"])
        local = int(os.environ.get("LOCAL_RANK", 0))
        torch.cuda.set_device(local)
        dist.init_process_group(backend="nccl")
        return rank, world, local
    return 0, 1, 0


def is_main_process():
    return not (dist.is_available() and dist.is_initialized()) or dist.get_rank() == 0


def world_size():
    if dist.is_available() and dist.is_initialized():
        return dist.get_world_size()
    return 1


def reduce_mean(tensor):
    if world_size() == 1:
        return tensor
    tensor = tensor.detach().clone()
    dist.all_reduce(tensor)
    return tensor / world_size()


def unwrap(model):
    return model.module if hasattr(model, "module") else model


def move_to_device(batch, device):
    if torch.is_tensor(batch):
        return batch.to(device, non_blocking=True)
    if isinstance(batch, dict):
        return {k: move_to_device(v, device) for k, v in batch.items()}
    if isinstance(batch, (list, tuple)):
        return type(batch)(move_to_device(v, device) for v in batch)
    return batch


def get_logger(name="charm", out_dir=None):
    logger = logging.getLogger(name)
    if logger.handlers:
        return logger
    logger.setLevel(logging.INFO if is_main_process() else logging.WARNING)
    fmt = logging.Formatter("[%(asctime)s] %(message)s", datefmt="%Y-%m-%d %H:%M:%S")
    stream = logging.StreamHandler(sys.stdout)
    stream.setFormatter(fmt)
    logger.addHandler(stream)
    if out_dir is not None and is_main_process():
        os.makedirs(out_dir, exist_ok=True)
        fh = logging.FileHandler(os.path.join(out_dir, "log.txt"))
        fh.setFormatter(fmt)
        logger.addHandler(fh)
    return logger


class AverageMeter:
    def __init__(self):
        self.sums = {}
        self.counts = {}

    def update(self, values):
        for key, value in values.items():
            value = float(value)
            self.sums[key] = self.sums.get(key, 0.0) + value
            self.counts[key] = self.counts.get(key, 0) + 1

    def averages(self):
        return {k: self.sums[k] / max(self.counts[k], 1) for k in self.sums}

    def reset(self):
        self.sums.clear()
        self.counts.clear()

    def __str__(self):
        return " ".join(f"{k}={v:.4f}" for k, v in self.averages().items())


def save_checkpoint(path, model, optimizer=None, scheduler=None, epoch=None, extra=None):
    if not is_main_process():
        return
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    state = {"model": unwrap(model).state_dict(), "epoch": epoch}
    if optimizer is not None:
        state["optimizer"] = optimizer.state_dict()
    if scheduler is not None:
        state["scheduler"] = scheduler.state_dict()
    if extra:
        state.update(extra)
    torch.save(state, path)


def load_checkpoint(path, model, optimizer=None, scheduler=None, strict=True, map_location="cpu"):
    state = torch.load(path, map_location=map_location)
    missing, unexpected = unwrap(model).load_state_dict(state["model"], strict=strict)
    if optimizer is not None and "optimizer" in state:
        optimizer.load_state_dict(state["optimizer"])
    if scheduler is not None and "scheduler" in state:
        scheduler.load_state_dict(state["scheduler"])
    return state.get("epoch"), missing, unexpected
