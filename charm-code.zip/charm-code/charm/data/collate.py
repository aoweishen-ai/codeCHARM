"""Batch collation with padding for boxes and variable-size point clouds."""

import numpy as np
import torch


def cooperative_collate(samples):
    B = len(samples)
    batch = {}
    skip = {"gt_boxes", "gt_cls"}
    for key in samples[0]:
        if key in skip or key.endswith("_points") or key.endswith("_points_shape"):
            continue
        batch[key] = torch.from_numpy(np.stack([np.asarray(s[key]) for s in samples]))

    M = max(1, max(len(s["gt_boxes"]) for s in samples))
    gt = np.zeros((B, M, 7), np.float32)
    mask = np.zeros((B, M), bool)
    cls = np.zeros((B, M), np.int64)
    for b, s in enumerate(samples):
        n = len(s["gt_boxes"])
        gt[b, :n] = s["gt_boxes"]
        mask[b, :n] = True
        cls[b, :n] = s["gt_cls"]
    batch["gt_boxes"] = torch.from_numpy(gt)
    batch["gt_mask"] = torch.from_numpy(mask)
    batch["gt_cls"] = torch.from_numpy(cls)

    for prefix in ("ego_", "hist_", "tgt_"):
        key = prefix + "points"
        if key not in samples[0]:
            continue
        lead = tuple(samples[0][prefix + "points_shape"])
        flats = [s[key] for s in samples]
        n = len(flats[0])
        P = max(1, max((p.shape[0] for f in flats for p in f), default=1))
        arr = np.zeros((B, n, P, 4), np.float32)
        num = np.zeros((B, n), np.int64)
        for b, f in enumerate(flats):
            for i, p in enumerate(f):
                arr[b, i, : len(p)] = p[:, :4]
                num[b, i] = len(p)
        batch[key] = torch.from_numpy(arr.reshape(B, *lead, P, 4))
        batch[prefix + "num_points"] = torch.from_numpy(num.reshape(B, *lead))
    return batch
