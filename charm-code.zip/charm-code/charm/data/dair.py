"""DAIR-V2X-C and V2X-Seq-SPD loader (vehicle ego, one infrastructure collaborator).

<root>/cooperative/data_info.json
<root>/cooperative/label[_world]/<vehicle_frame>.json
<root>/vehicle-side/{data_info.json, image/, velodyne/, calib/{camera_intrinsic, lidar_to_camera,
                    lidar_to_novatel, novatel_to_world}/}
<root>/infrastructure-side/{data_info.json, image/, velodyne/, calib/{camera_intrinsic,
                    virtuallidar_to_camera, virtuallidar_to_world}/}
"""

import bisect
import json
import math
import os
from collections import defaultdict

import numpy as np

from ..utils.geometry import rt_to_matrix
from .base import CooperativeDataset
from .io import load_image, load_json, read_pcd

VEHICLE_CLASSES = {"car", "van", "bus", "truck", "motor_vehicle", "vehicle"}


def _stem(path):
    return os.path.splitext(os.path.basename(path))[0]


def _read_rt(path):
    d = load_json(path)
    if "transform" in d:
        d = d["transform"]
    return rt_to_matrix(d["rotation"], d["translation"])


def _read_intrinsic(path):
    d = load_json(path)
    return np.asarray(d["cam_K"], dtype=np.float64).reshape(3, 3)


class DairV2XDataset(CooperativeDataset):
    def __init__(self, cfg, split, train):
        super().__init__(cfg, split, train)
        d = self.dcfg
        self.root = d["root"]
        self.label_dir = d.get("label_dir")  # e.g. "cooperative/label_world" for complemented labels
        coop = load_json(os.path.join(self.root, "cooperative", "data_info.json"))
        veh = load_json(os.path.join(self.root, "vehicle-side", "data_info.json"))
        inf = load_json(os.path.join(self.root, "infrastructure-side", "data_info.json"))
        self.veh = {self._frame_id(e): e for e in veh}
        self.inf = {self._frame_id(e): e for e in inf}

        groups = defaultdict(list)
        for fid, e in self.inf.items():
            groups[str(e.get("sequence_id", e.get("batch_id", "all")))].append(fid)
        self.inf_seq, self.inf_seq_times, self.inf_key = {}, {}, {}
        for key, ids in groups.items():
            ids.sort(key=lambda f: self._timestamp(self.inf[f]))
            self.inf_seq[key] = ids
            self.inf_seq_times[key] = [self._timestamp(self.inf[f]) for f in ids]
            for f in ids:
                self.inf_key[f] = key

        allowed = self._load_split(d.get("split_file"), d.get(f"{split}_split_name", split))
        self.samples = []
        for e in coop:
            vf = str(e.get("vehicle_frame") or _stem(e.get("vehicle_image_path") or e["vehicle_pointcloud_path"]))
            inf_f = str(e.get("infrastructure_frame") or _stem(e.get("infrastructure_image_path") or e["infrastructure_pointcloud_path"]))
            if vf not in self.veh or inf_f not in self.inf:
                continue
            if allowed is not None and vf not in allowed and str(e.get("vehicle_sequence", "")) not in allowed:
                continue
            self.samples.append({
                "veh": vf,
                "inf": inf_f,
                "offset": e.get("system_error_offset") or {"delta_x": 0.0, "delta_y": 0.0},
                "label": e.get("cooperative_label_path"),
            })

    # ----------------------------------------------------------------------------- helpers
    @staticmethod
    def _frame_id(e):
        if "frame_id" in e:
            return str(e["frame_id"])
        return _stem(e.get("image_path") or e["pointcloud_path"])

    def _timestamp(self, e):
        key = "image_timestamp" if self.modality == "camera" else "pointcloud_timestamp"
        value = e.get(key, e.get("image_timestamp", e.get("pointcloud_timestamp", 0)))
        return int(value) / 1e6

    @staticmethod
    def _load_split(path, split):
        if not path:
            return None
        with open(path, "r") as f:
            obj = json.load(f)
        if isinstance(obj, dict):
            if "cooperative_split" in obj:
                obj = obj["cooperative_split"]
            obj = obj.get(split, [])
        return {str(x) for x in obj}

    def __len__(self):
        return len(self.samples)

    # ----------------------------------------------------------------------------- hooks
    def _sample_meta(self, idx, rng):
        s = self.samples[idx]
        ego_time = self._timestamp(self.veh[s["veh"]])
        return {
            "sample": s,
            "ego": {"side": "vehicle", "frame": s["veh"], "time": ego_time},
            "ego_time": ego_time,
            "collaborators": [{"side": "infrastructure", "frame": s["inf"]}][: self.max_collab],
        }

    def _history(self, agent, meta):
        key = self.inf_key[agent["frame"]]
        ids, times = self.inf_seq[key], self.inf_seq_times[key]
        end = bisect.bisect_right(times, meta["ego_time"] + 1e-6)
        start = max(0, end - self.history_window)
        return [{"side": "infrastructure", "frame": ids[i], "time": times[i]} for i in range(start, end)]

    def _target(self, agent, meta):
        fid = agent["frame"]
        return {"side": "infrastructure", "frame": fid, "time": self._timestamp(self.inf[fid])}

    def _relative_pose(self, world_T_ego, world_T_agent, meta, agent):
        T = np.linalg.inv(world_T_ego) @ world_T_agent
        off = meta["sample"]["offset"]
        T[0, 3] += float(off.get("delta_x", 0.0))
        T[1, 3] += float(off.get("delta_y", 0.0))
        return T

    def _load_frame(self, ref, want_depth=False, want_points=False):
        fid = ref["frame"]
        if ref["side"] == "vehicle":
            e = self.veh[fid]
            base = os.path.join(self.root, "vehicle-side")
            calib = os.path.join(base, "calib")
            agent_T_cam_inv = _read_rt(os.path.join(calib, "lidar_to_camera", fid + ".json"))
            world_T = _read_rt(os.path.join(calib, "novatel_to_world", fid + ".json")) @ _read_rt(
                os.path.join(calib, "lidar_to_novatel", fid + ".json")
            )
        else:
            e = self.inf[fid]
            base = os.path.join(self.root, "infrastructure-side")
            calib = os.path.join(base, "calib")
            agent_T_cam_inv = _read_rt(os.path.join(calib, "virtuallidar_to_camera", fid + ".json"))
            world_T = _read_rt(os.path.join(calib, "virtuallidar_to_world", fid + ".json"))
        frame = {"world_T": world_T}
        if want_points or want_depth:
            rel = e.get("pointcloud_path")
            pcd = os.path.join(base, rel) if rel and os.path.exists(os.path.join(base, rel)) else os.path.join(base, "velodyne", fid + ".pcd")
            if not os.path.exists(pcd) and rel:
                pcd = os.path.join(self.root, rel)
            frame["points"] = read_pcd(pcd) if os.path.exists(pcd) else np.zeros((0, 4), np.float32)
        if self.modality == "camera":
            rel = e.get("image_path")
            img = os.path.join(base, rel) if rel and os.path.exists(os.path.join(base, rel)) else os.path.join(base, "image", fid + ".jpg")
            if not os.path.exists(img) and rel:
                img = os.path.join(self.root, rel)
            K = _read_intrinsic(os.path.join(calib, "camera_intrinsic", fid + ".json"))
            arr, K = load_image(img, K, self.image_size)
            V = self.num_cameras
            imgs = np.zeros((V, 3) + self.image_size, np.uint8)
            intr = np.tile(np.eye(3), (V, 1, 1))
            c2a = np.tile(np.eye(4), (V, 1, 1))
            imgs[0], intr[0], c2a[0] = arr, K, np.linalg.inv(agent_T_cam_inv)
            frame.update(imgs=imgs, intr=intr.astype(np.float32), cam2agent=c2a.astype(np.float32))
        return frame

    def _gt_boxes(self, meta, world_T_ego):
        s = meta["sample"]
        rel = s["label"]
        if self.label_dir:
            path = os.path.join(self.root, self.label_dir, s["veh"] + ".json")
        elif rel:
            path = os.path.join(self.root, rel)
        else:
            path = os.path.join(self.root, "cooperative", "label", s["veh"] + ".json")
        if not os.path.exists(path):
            return np.zeros((0, 7), np.float32)
        in_world = "label_world" in path
        ego_T_world = np.linalg.inv(world_T_ego)
        boxes = []
        for obj in load_json(path):
            if str(obj.get("type", "")).lower() not in VEHICLE_CLASSES:
                continue
            dims, loc = obj["3d_dimensions"], obj["3d_location"]
            x, y, z = float(loc["x"]), float(loc["y"]), float(loc["z"])
            yaw = float(obj.get("rotation", 0.0))
            if in_world:
                p = ego_T_world @ np.array([x, y, z, 1.0])
                x, y, z = p[:3]
                yaw = yaw + math.atan2(ego_T_world[1, 0], ego_T_world[0, 0])
            boxes.append([x, y, z, float(dims["l"]), float(dims["w"]), float(dims["h"]), yaw])
        return np.asarray(boxes, dtype=np.float32).reshape(-1, 7)
