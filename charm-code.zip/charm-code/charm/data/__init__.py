from .collate import cooperative_collate
from .dair import DairV2XDataset
from .opencood import OpenCOODDataset

_REGISTRY = {
    "opv2v": OpenCOODDataset,
    "v2xset": OpenCOODDataset,
    "v2v4real": OpenCOODDataset,
    "dair_v2x_c": DairV2XDataset,
    "v2x_seq_spd": DairV2XDataset,
}


def build_dataset(cfg, split, train):
    name = cfg["dataset"]["name"].lower()
    if name not in _REGISTRY:
        raise ValueError(f"unknown dataset: {name}")
    return _REGISTRY[name](cfg, split, train)


__all__ = ["build_dataset", "cooperative_collate", "OpenCOODDataset", "DairV2XDataset"]
