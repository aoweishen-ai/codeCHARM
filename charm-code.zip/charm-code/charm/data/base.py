"""Common cooperative dataset logic: history selection through the simulated channel, pose noise,
padding of agent-frames and ground-truth assembly."""

import numpy as np
from torch.utils.data import Dataset

from ..channel.estimator import channel_scalars
from ..channel.simulator import ChannelParams, ChannelSampler
from ..utils.box_ops import filter_boxes_in_range
from ..utils.geometry import perturb_pose_matrix
from .io import depth_from_points


class CooperativeDataset(Dataset):
    """Subclasses implement:

    __len__()
    _sample_meta(idx, rng) -> {"ego": FrameRef, "ego_time": float, "collaborators": [AgentRef, ...], ...}
    _history(agent, meta)  -> ascending list of FrameRefs (each with absolute "time")
    _target(agent, meta)   -> FrameRef at the ego timestamp (or None)
    _load_frame(ref, want_depth, want_points) -> {"world_T", "imgs", "intr", "cam2agent", "depth", "points"}
    _gt_boxes(meta, world_T_ego) -> (M, 7) boxes in the ego frame
    """

    def __init__(self, cfg, split, train):
        self.cfg = cfg
        self.dcfg = cfg["dataset"]
        self.split = split
        self.train = train
        self.modality = cfg["model"].get("modality", "camera")
        d = self.dcfg
        self.num_cameras = int(d.get("num_cameras", 4))
        self.image_size = tuple(d.get("image_size", [384, 512]))
        ie = cfg["model"].get("image_encoder", {})
        self.stride = int(ie.get("stride", 16))
        self.depth_min = float(ie.get("depth_min", 1.0))
        self.depth_max = self.depth_min + float(ie.get("depth_step", 0.85)) * int(ie.get("num_depth_bins", 59))
        self.depth_supervision = bool(d.get("depth_supervision", True)) and train and self.modality == "camera"
        self.max_collab = int(d.get("max_collaborators", 2))
        self.K = int(d.get("buffer_size", 4))
        self.history_window = int(d.get("history_window", 10))
        self.period = float(d.get("frame_period", 0.1))
        self.comm_range = float(d.get("comm_range", 70.0))
        self.max_points = int(d.get("max_points", 150000))
        self.load_targets = train
        bev = cfg["model"]["bev"]
        self.x_range, self.y_range = bev["x_range"], bev["y_range"]

        ch = cfg.get("channel", {})
        self.channel = ChannelSampler(
            ChannelParams.from_dict(ch.get("nominal", {})),
            ch.get("randomization"),
            mode="randomized" if train else "realistic",
            buffer_size=self.K,
            rho_window=int(ch.get("rho_window_frames", 20)),
            packets_per_frame=int(ch.get("packets_per_frame_estimate", 64)),
        )
        self.base_seed = int(cfg.get("train", {}).get("seed", 0))
        self.epoch = 0

    # ----------------------------------------------------------------------------- control
    def set_channel(self, mode, params=None, seed=None):
        self.channel.mode = mode
        if params is not None:
            self.channel.nominal = params
        if seed is not None:
            self.base_seed = int(seed)

    def set_epoch(self, epoch, curriculum_scale=1.0, tail=True):
        self.epoch = int(epoch)
        self.channel.set_curriculum(curriculum_scale, tail)

    # ----------------------------------------------------------------------------- hooks
    def _relative_pose(self, world_T_ego, world_T_agent, meta, agent):
        return np.linalg.inv(world_T_ego) @ world_T_agent

    def _subsample_points(self, pts, rng):
        if pts is None or len(pts) <= self.max_points:
            return pts
        keep = rng.choice(len(pts), self.max_points, replace=False)
        return pts[keep]

    def _depth_maps(self, points, intr, cam2agent):
        return np.stack(
            [
                depth_from_points(points, cam2agent[v], intr[v], self.image_size, self.stride, self.depth_min, self.depth_max)
                for v in range(len(intr))
            ]
        ).astype(np.float32)

    # ----------------------------------------------------------------------------- assembly
    def _pack_frames(self, frames, lead_shape, prefix, out):
        V = self.num_cameras
        H, W = self.image_size
        h, w = H // self.stride, W // self.stride
        n = len(frames)
        if self.modality == "camera":
            imgs = np.zeros((n, V, 3, H, W), np.uint8)
            intr = np.tile(np.eye(3, dtype=np.float32), (n, V, 1, 1))
            c2a = np.tile(np.eye(4, dtype=np.float32), (n, V, 1, 1))
            depth = np.zeros((n, V, h, w), np.float32) if self.depth_supervision else None
            for i, fr in enumerate(frames):
                if fr is None:
                    continue
                imgs[i] = fr["imgs"]
                intr[i] = fr["intr"]
                c2a[i] = fr["cam2agent"]
                if depth is not None and fr.get("depth") is not None:
                    depth[i] = fr["depth"]
            out[prefix + "imgs"] = imgs.reshape(*lead_shape, V, 3, H, W)
            out[prefix + "intr"] = intr.reshape(*lead_shape, V, 3, 3)
            out[prefix + "cam2agent"] = c2a.reshape(*lead_shape, V, 4, 4)
            if depth is not None:
                out[prefix + "depth"] = depth.reshape(*lead_shape, V, h, w)
        else:
            out[prefix + "points"] = [
                fr["points"] if fr is not None and fr.get("points") is not None else np.zeros((0, 4), np.float32)
                for fr in frames
            ]
            out[prefix + "points_shape"] = tuple(lead_shape)

    def _load(self, ref, rng):
        want_points = self.modality == "lidar"
        fr = self._load_frame(ref, want_depth=self.depth_supervision, want_points=want_points or self.depth_supervision)
        if self.depth_supervision and fr.get("points") is not None and self.modality == "camera":
            fr["depth"] = self._depth_maps(fr["points"], fr["intr"], fr["cam2agent"])
        if want_points:
            fr["points"] = self._subsample_points(fr.get("points"), rng)
        return fr

    def __getitem__(self, idx):
        rng = np.random.default_rng([self.base_seed, self.epoch if self.train else 0, int(idx)])
        meta = self._sample_meta(idx, rng)
        ego = self._load(meta["ego"], rng)
        world_T_ego = ego["world_T"]
        J, K = self.max_collab, self.K

        hist = [None] * (J * K)
        hist_valid = np.zeros((J, K), bool)
        hist_times = np.zeros((J, K), np.float32)
        hist_T = np.tile(np.eye(4, dtype=np.float32), (J, K, 1, 1))
        present = np.zeros(J, bool)
        scalars = np.zeros((J, 4), np.float32)
        ge = np.zeros((J, 5), np.float32)
        seeds = np.zeros(J, np.int64)
        budget = np.full(J, np.inf, np.float32)
        tgt = [None] * J
        tgt_valid = np.zeros(J, bool)
        tgt_T = np.tile(np.eye(4, dtype=np.float32), (J, 1, 1))

        for j, agent in enumerate(meta["collaborators"][:J]):
            cands = self._history(agent, meta)
            gen_times = [c["time"] - meta["ego_time"] for c in cands]
            link = self.channel.sample_link(gen_times, rng)
            present[j] = True
            sel = link["selected"]
            offset = K - len(sel)
            for n, ci in enumerate(sel):
                fr = self._load(cands[ci], rng)
                noisy = perturb_pose_matrix(fr["world_T"], link["sigma_t"], link["sigma_r_deg"], rng)
                slot = offset + n
                hist[j * K + slot] = fr
                hist_T[j, slot] = self._relative_pose(world_T_ego, noisy, meta, agent)
                hist_times[j, slot] = gen_times[ci]
                hist_valid[j, slot] = True
            scalars[j] = channel_scalars(link["tau_hat"], link["rho_hat"], link["snr_db"], link["budget"])
            ge[j] = link["ge"]
            seeds[j] = link["seed"]
            budget[j] = link["budget"]
            if self.load_targets:
                tref = self._target(agent, meta)
                if tref is not None:
                    fr = self._load(tref, rng)
                    noisy = perturb_pose_matrix(fr["world_T"], link["sigma_t"], link["sigma_r_deg"], rng)
                    tgt[j] = fr
                    tgt_T[j] = self._relative_pose(world_T_ego, noisy, meta, agent)
                    tgt_valid[j] = True

        sample = {}
        self._pack_frames([ego], (), "ego_", sample)
        self._pack_frames(hist, (J, K), "hist_", sample)
        if self.load_targets:
            self._pack_frames(tgt, (J,), "tgt_", sample)
            sample["tgt_valid"] = tgt_valid
            sample["tgt_T"] = tgt_T

        boxes = filter_boxes_in_range(self._gt_boxes(meta, world_T_ego), self.x_range, self.y_range)
        sample.update(
            hist_valid=hist_valid,
            hist_times=hist_times,
            hist_T=hist_T,
            present=present,
            channel_scalars=scalars,
            ge_params=ge,
            link_seed=seeds,
            budget=budget,
            gt_boxes=boxes.astype(np.float32),
            gt_cls=np.zeros(len(boxes), np.int64),
        )
        return sample
