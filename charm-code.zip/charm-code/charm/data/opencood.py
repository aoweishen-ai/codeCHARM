"""OPV2V, V2XSet and V2V4Real loader (OpenCOOD folder layout).

<root>/<split>/<scenario>/<agent_id>/<timestamp>.yaml
                                    /<timestamp>_camera<i>.png
                                    /<timestamp>.pcd
Infrastructure agents in V2XSet use negative ids and are placed after vehicles.
"""

import math
import os

import numpy as np

from ..utils.geometry import CV_TO_UE, pose_to_matrix
from .base import CooperativeDataset
from .io import load_image, load_yaml, read_pcd


def _is_int(name):
    try:
        int(name)
        return True
    except ValueError:
        return False


class OpenCOODDataset(CooperativeDataset):
    def __init__(self, cfg, split, train):
        super().__init__(cfg, split, train)
        d = self.dcfg
        split_dir = d.get(f"{split}_dir", split)
        self.root = os.path.join(d["root"], split_dir)
        self.objects_frame = d.get("objects_frame", "world")
        all_egos = bool(d.get("all_agents_as_ego", False)) and train
        self.scenarios = []
        self.index = []
        for name in sorted(os.listdir(self.root)):
            spath = os.path.join(self.root, name)
            if not os.path.isdir(spath):
                continue
            cavs = [c for c in os.listdir(spath) if os.path.isdir(os.path.join(spath, c)) and _is_int(c)]
            if not cavs:
                continue
            cavs = sorted([c for c in cavs if int(c) >= 0], key=int) + sorted([c for c in cavs if int(c) < 0], key=int)
            stamps = {}
            for c in cavs:
                files = os.listdir(os.path.join(spath, c))
                stamps[c] = sorted(f[:-5] for f in files if f.endswith(".yaml") and f[:-5].isdigit())
            stamp_index = {c: {s: i for i, s in enumerate(stamps[c])} for c in cavs}
            si = len(self.scenarios)
            self.scenarios.append({"path": spath, "cavs": cavs, "stamps": stamps, "stamp_index": stamp_index})
            egos = [c for c in cavs if int(c) >= 0] if all_egos else [cavs[0]]
            for ego in egos:
                for ts in stamps[ego]:
                    self.index.append((si, ego, ts))

    def __len__(self):
        return len(self.index)

    # ----------------------------------------------------------------------------- helpers
    def _yaml_path(self, si, cav, ts):
        return os.path.join(self.scenarios[si]["path"], cav, ts + ".yaml")

    def _meta(self, si, cav, ts):
        return load_yaml(self._yaml_path(si, cav, ts))

    def _time(self, si, cav, ts):
        return self.scenarios[si]["stamp_index"][cav][ts] * self.period

    # ----------------------------------------------------------------------------- hooks
    def _sample_meta(self, idx, rng):
        si, ego, ts = self.index[idx]
        sc = self.scenarios[si]
        ego_pos = np.asarray(self._meta(si, ego, ts)["lidar_pose"][:2], dtype=np.float64)
        neighbours = []
        for c in sc["cavs"]:
            if c == ego or ts not in sc["stamp_index"][c]:
                continue
            pos = np.asarray(self._meta(si, c, ts)["lidar_pose"][:2], dtype=np.float64)
            dist = float(np.linalg.norm(pos - ego_pos))
            if dist <= self.comm_range:
                neighbours.append((dist, c))
        neighbours.sort()
        in_range = [c for _, c in neighbours]
        ego_time = self._time(si, ego, ts)
        return {
            "scenario": si,
            "ts": ts,
            "ego": {"scenario": si, "cav": ego, "ts": ts, "time": ego_time},
            "ego_time": ego_time,
            "collaborators": [{"scenario": si, "cav": c} for c in in_range[: self.max_collab]],
            "gt_sources": [ego] + in_range,
        }

    def _history(self, agent, meta):
        sc = self.scenarios[agent["scenario"]]
        cav = agent["cav"]
        stamps = sc["stamps"][cav]
        cur = sc["stamp_index"][cav][meta["ts"]]
        refs = []
        for h in range(self.history_window - 1, -1, -1):
            k = cur - h
            if k < 0:
                continue
            refs.append({"scenario": agent["scenario"], "cav": cav, "ts": stamps[k], "time": meta["ego_time"] - h * self.period})
        return refs

    def _target(self, agent, meta):
        return {"scenario": agent["scenario"], "cav": agent["cav"], "ts": meta["ts"], "time": meta["ego_time"]}

    def _load_frame(self, ref, want_depth=False, want_points=False):
        si, cav, ts = ref["scenario"], ref["cav"], ref["ts"]
        base = os.path.join(self.scenarios[si]["path"], cav)
        meta = self._meta(si, cav, ts)
        world_T = pose_to_matrix(meta["lidar_pose"])
        frame = {"world_T": world_T}
        if want_points or want_depth:
            pcd = os.path.join(base, ts + ".pcd")
            frame["points"] = read_pcd(pcd) if os.path.exists(pcd) else np.zeros((0, 4), np.float32)
        if self.modality == "camera":
            V = self.num_cameras
            H, W = self.image_size
            imgs = np.zeros((V, 3, H, W), np.uint8)
            intr = np.tile(np.eye(3), (V, 1, 1))
            c2a = np.tile(np.eye(4), (V, 1, 1))
            lidar_T_world = np.linalg.inv(world_T)
            for v in range(V):
                cam = meta.get(f"camera{v}")
                path = os.path.join(base, f"{ts}_camera{v}.png")
                if cam is None or not os.path.exists(path):
                    continue
                imgs[v], intr[v] = load_image(path, cam["intrinsic"], self.image_size)
                c2a[v] = lidar_T_world @ pose_to_matrix(cam["cords"]) @ CV_TO_UE
            frame.update(imgs=imgs, intr=intr.astype(np.float32), cam2agent=c2a.astype(np.float32))
        return frame

    def _gt_boxes(self, meta, world_T_ego):
        si, ts = meta["scenario"], meta["ts"]
        objects = {}
        for cav in meta["gt_sources"]:
            m = self._meta(si, cav, ts)
            world_T_cav = pose_to_matrix(m["lidar_pose"])
            for oid, obj in (m.get("vehicles") or {}).items():
                if oid in objects:
                    continue
                loc, ctr, ang = obj["location"], obj.get("center", [0, 0, 0]), obj["angle"]
                pose = [loc[0] + ctr[0], loc[1] + ctr[1], loc[2] + ctr[2], ang[0], ang[1], ang[2]]
                T = pose_to_matrix(pose)
                if self.objects_frame != "world":
                    T = world_T_cav @ T
                objects[oid] = (T, obj["extent"])
        ego_T_world = np.linalg.inv(world_T_ego)
        boxes = []
        for T, extent in objects.values():
            rel = ego_T_world @ T
            x, y, z = rel[:3, 3]
            yaw = math.atan2(rel[1, 0], rel[0, 0])
            boxes.append([x, y, z, 2 * extent[0], 2 * extent[1], 2 * extent[2], yaw])
        return np.asarray(boxes, dtype=np.float32).reshape(-1, 7)
