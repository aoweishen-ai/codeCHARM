"""File readers: YAML with scientific-notation floats, JSON, PCD point clouds and images."""

import functools
import json
import re

import numpy as np
import yaml
from PIL import Image


class _FloatLoader(yaml.SafeLoader):
    pass


_FloatLoader.add_implicit_resolver(
    "tag:yaml.org,2002:float",
    re.compile(
        r"""^(?:[-+]?(?:[0-9][0-9_]*)\.[0-9_]*(?:[eE][-+]?[0-9]+)?
        |[-+]?(?:[0-9][0-9_]*)(?:[eE][-+]?[0-9]+)
        |\.[0-9_]+(?:[eE][-+][0-9]+)?
        |[-+]?[0-9][0-9_]*(?::[0-5]?[0-9])+\.[0-9_]*
        |[-+]?\.(?:inf|Inf|INF)
        |\.(?:nan|NaN|NAN))$""",
        re.X,
    ),
    list("-+0123456789."),
)


@functools.lru_cache(maxsize=8192)
def load_yaml(path):
    with open(path, "r") as f:
        return yaml.load(f, Loader=_FloatLoader)


@functools.lru_cache(maxsize=8192)
def load_json(path):
    with open(path, "r") as f:
        return json.load(f)


_PCD_TYPES = {
    ("F", 4): np.float32, ("F", 8): np.float64,
    ("U", 1): np.uint8, ("U", 2): np.uint16, ("U", 4): np.uint32, ("U", 8): np.uint64,
    ("I", 1): np.int8, ("I", 2): np.int16, ("I", 4): np.int32, ("I", 8): np.int64,
}


def read_pcd(path):
    """Read x, y, z and intensity from an ASCII or binary PCD file. Returns (P, 4) float32."""
    with open(path, "rb") as f:
        header = {}
        while True:
            line = f.readline()
            if not line:
                raise ValueError(f"unexpected end of PCD header in {path}")
            line = line.decode("ascii", errors="ignore").strip()
            if not line or line.startswith("#"):
                continue
            key, *vals = line.split()
            header[key.upper()] = vals
            if key.upper() == "DATA":
                break
        fields = [x.lower() for x in header["FIELDS"]]
        sizes = [int(x) for x in header["SIZE"]]
        types = header["TYPE"]
        counts = [int(x) for x in header.get("COUNT", ["1"] * len(fields))]
        n = int(header["POINTS"][0])
        mode = header["DATA"][0].lower()
        dtype = []
        for name, size, typ, cnt in zip(fields, sizes, types, counts):
            npt = _PCD_TYPES[(typ, size)]
            dtype.append((name, npt) if cnt == 1 else (name, npt, (cnt,)))
        dtype = np.dtype(dtype)
        if mode == "ascii":
            raw = np.loadtxt(f, dtype=np.float64, ndmin=2)
            cols = {}
            offset = 0
            for name, cnt in zip(fields, counts):
                cols[name] = raw[:, offset]
                offset += cnt
        elif mode == "binary":
            data = np.frombuffer(f.read(n * dtype.itemsize), dtype=dtype, count=n)
            cols = {name: data[name] for name in fields}
        else:
            try:
                import open3d as o3d
            except ImportError as exc:
                raise ValueError(f"unsupported PCD encoding '{mode}' in {path}; install open3d") from exc
            pcd = o3d.io.read_point_cloud(path)
            xyz = np.asarray(pcd.points, dtype=np.float32)
            return np.concatenate([xyz, np.zeros((len(xyz), 1), np.float32)], axis=1)
    xyz = np.stack([cols["x"], cols["y"], cols["z"]], axis=1).astype(np.float32)
    inten = cols.get("intensity", cols.get("i", np.zeros(len(xyz))))
    pts = np.concatenate([xyz, np.asarray(inten, np.float32).reshape(-1, 1)], axis=1)
    return pts[np.isfinite(pts).all(axis=1)]


def load_image(path, intrinsic, size):
    """Load an RGB image, resize it to ``size`` = (H, W) and rescale the intrinsics accordingly.

    Returns uint8 (3, H, W) and the adjusted 3x3 intrinsic matrix.
    """
    img = Image.open(path).convert("RGB")
    w0, h0 = img.size
    H, W = size
    img = img.resize((W, H), Image.BILINEAR)
    sx, sy = W / float(w0), H / float(h0)
    K = np.asarray(intrinsic, dtype=np.float64).reshape(3, 3).copy()
    K[0, 0] *= sx
    K[0, 2] *= sx
    K[1, 1] *= sy
    K[1, 2] *= sy
    arr = np.asarray(img, dtype=np.uint8).transpose(2, 0, 1).copy()
    return arr, K


def depth_from_points(points, cam2agent, K, image_size, stride, d_min, d_max):
    """Project agent-frame LiDAR points into a camera; keep the nearest depth per feature cell."""
    H, W = image_size
    fh, fw = H // stride, W // stride
    depth = np.full((fh, fw), np.inf, dtype=np.float32)
    if points is None or len(points) == 0:
        return np.zeros((fh, fw), np.float32)
    agent2cam = np.linalg.inv(cam2agent)
    pc = points[:, :3] @ agent2cam[:3, :3].T + agent2cam[:3, 3]
    z = pc[:, 2]
    keep = (z > d_min) & (z < d_max)
    pc, z = pc[keep], z[keep]
    if len(pc) == 0:
        return np.zeros((fh, fw), np.float32)
    uv = pc @ np.asarray(K).T
    u = uv[:, 0] / uv[:, 2]
    v = uv[:, 1] / uv[:, 2]
    inside = (u >= 0) & (u < W) & (v >= 0) & (v < H)
    iu = (u[inside] // stride).astype(np.int64)
    iv = (v[inside] // stride).astype(np.int64)
    np.minimum.at(depth, (iv, iu), z[inside].astype(np.float32))
    depth[~np.isfinite(depth)] = 0.0
    return depth
