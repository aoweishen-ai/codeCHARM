"""BEV average precision, robustness summaries and communication volume."""

import math

import numpy as np

from ..utils.box_ops import bev_iou_matrix


def _trapezoid(y, x, axis=-1):
    fn = getattr(np, "trapezoid", None) or np.trapz
    return fn(y, x, axis=axis)


def voc_ap(recall, precision):
    """All-point interpolated average precision."""
    mrec = np.concatenate([[0.0], recall, [1.0]])
    mpre = np.concatenate([[0.0], precision, [0.0]])
    for i in range(len(mpre) - 2, -1, -1):
        mpre[i] = max(mpre[i], mpre[i + 1])
    idx = np.nonzero(mrec[1:] != mrec[:-1])[0]
    return float(np.sum((mrec[idx + 1] - mrec[idx]) * mpre[idx + 1]))


class APAccumulator:
    def __init__(self, iou_thresholds=(0.5, 0.7)):
        self.thresholds = [float(t) for t in iou_thresholds]
        self.reset()

    def reset(self):
        self.records = {t: {"scores": [], "tp": [], "n_gt": 0} for t in self.thresholds}

    def add(self, pred_boxes, pred_scores, gt_boxes):
        pred_boxes = np.asarray(pred_boxes).reshape(-1, 7)
        pred_scores = np.asarray(pred_scores).reshape(-1)
        gt_boxes = np.asarray(gt_boxes).reshape(-1, 7)
        order = np.argsort(-pred_scores)
        pred_boxes, pred_scores = pred_boxes[order], pred_scores[order]
        iou = bev_iou_matrix(pred_boxes, gt_boxes) if len(pred_boxes) and len(gt_boxes) else None
        for t in self.thresholds:
            rec = self.records[t]
            rec["n_gt"] += len(gt_boxes)
            tp = np.zeros(len(pred_boxes), np.float64)
            if iou is not None:
                matched = np.zeros(len(gt_boxes), bool)
                for i in range(len(pred_boxes)):
                    cand = np.where(matched, -1.0, iou[i])
                    j = int(np.argmax(cand))
                    if cand[j] >= t:
                        tp[i] = 1.0
                        matched[j] = True
            rec["scores"].append(pred_scores)
            rec["tp"].append(tp)

    def compute(self):
        out = {}
        for t in self.thresholds:
            rec = self.records[t]
            if rec["n_gt"] == 0:
                out[f"AP@{t}"] = 0.0
                continue
            scores = np.concatenate(rec["scores"]) if rec["scores"] else np.zeros(0)
            tp = np.concatenate(rec["tp"]) if rec["tp"] else np.zeros(0)
            order = np.argsort(-scores, kind="stable")
            tp = tp[order]
            fp = 1.0 - tp
            tp_c, fp_c = np.cumsum(tp), np.cumsum(fp)
            recall = tp_c / rec["n_gt"]
            precision = tp_c / np.maximum(tp_c + fp_c, 1e-9)
            out[f"AP@{t}"] = 100.0 * voc_ap(recall, precision)
        return out


def robustness_area(ap_grid, taus, rhos):
    """Normalised area under the joint latency/loss degradation surface (trapezoidal rule).

    ap_grid: (len(taus), len(rhos)) with ap_grid[0, 0] the impairment-free accuracy.
    """
    ap_grid = np.asarray(ap_grid, dtype=np.float64)
    taus = np.asarray(taus, dtype=np.float64)
    rhos = np.asarray(rhos, dtype=np.float64)
    norm = ap_grid / max(ap_grid[0, 0], 1e-9)
    inner = _trapezoid(norm, rhos, axis=1)
    outer = _trapezoid(inner, taus)
    return float(outer / ((taus[-1] - taus[0]) * (rhos[-1] - rhos[0])))


def graceful_degradation_index(ap_grid):
    ap_grid = np.asarray(ap_grid, dtype=np.float64)
    return float(ap_grid[-1, -1] / max(ap_grid[0, 0], 1e-9))


def communication_volume(bytes_per_link):
    """log2 of the mean transmitted bytes per frame per link."""
    b = np.asarray(bytes_per_link, dtype=np.float64)
    if b.size == 0 or b.mean() <= 0:
        return 0.0
    return float(math.log2(b.mean()))
