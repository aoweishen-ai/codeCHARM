"""Evaluation loop and multi-seed channel evaluation."""

import numpy as np
import torch
from torch.utils.data import DataLoader

from ..data import cooperative_collate
from ..utils.misc import move_to_device
from .metrics import APAccumulator, communication_volume


@torch.no_grad()
def run_evaluation(model, loader, device, iou_thresholds=(0.5, 0.7), amp=True, progress=False):
    model.eval()
    acc = APAccumulator(iou_thresholds)
    transmitted = []
    iterator = loader
    if progress:
        from tqdm import tqdm

        iterator = tqdm(loader, leave=False)
    for batch in iterator:
        batch = move_to_device(batch, device)
        with torch.autocast(device_type=device.type, dtype=torch.bfloat16, enabled=amp and device.type == "cuda"):
            out = model(batch, return_loss=False)
        gt = batch["gt_boxes"].cpu().numpy()
        mask = batch["gt_mask"].cpu().numpy().astype(bool)
        for b, det in enumerate(out["detections"]):
            acc.add(det["boxes"], det["scores"], gt[b][mask[b]])
        active = out["link_active"]
        transmitted.extend(out["bytes"][active].float().cpu().numpy().tolist())
    result = acc.compute()
    result["comm_log2_bytes"] = communication_volume(transmitted)
    return result


def evaluate_over_seeds(model, dataset, device, mode, params=None, seeds=(0, 1, 2, 3, 4),
                        batch_size=1, num_workers=4, iou_thresholds=(0.5, 0.7), progress=False):
    """Mean and standard deviation over channel seeds with a fixed checkpoint and data order."""
    runs = []
    for seed in seeds:
        dataset.set_channel(mode, params=params, seed=seed)
        torch.manual_seed(int(seed))
        loader = DataLoader(
            dataset, batch_size=batch_size, shuffle=False, num_workers=num_workers,
            collate_fn=cooperative_collate, pin_memory=True,
        )
        runs.append(run_evaluation(model, loader, device, iou_thresholds, progress=progress))
        if mode == "ideal":
            break
    keys = runs[0].keys()
    summary = {}
    for key in keys:
        values = np.array([r[key] for r in runs], dtype=np.float64)
        summary[key] = {"mean": float(values.mean()), "std": float(values.std()), "runs": values.tolist()}
    return summary
