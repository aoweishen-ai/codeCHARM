# Ablation overrides

Every ablation variant is a dotted override on top of a dataset config, for example:

```
python tools/train.py --config configs/opv2v_camera.yaml --opts model.predictor.type=gru train.out_dir=outputs/abl_gru
```

| Variant | Override |
|---|---|
| Base: zero fill, max fusion, no channel state | `model.restorer.type=zero model.fusion.type=max model.channel_embedding.enabled=false`, then add components back one at a time |
| Gated recurrent unit predictor | `model.predictor.type=gru` |
| Temporal self-attention predictor | `model.predictor.type=attention` |
| BEV flow warping predictor | `model.predictor.type=flow` |
| No physical step size | `model.predictor.type=ssm_uniform` |
| Zero filling | `model.restorer.type=zero` |
| Deterministic L1 regressor | `model.restorer.type=regressor` |
| Without ego conditioning | `model.restorer.ego_conditioning=false` |
| Fixed top-k selection | `model.message.gate=topk` |
| No reliability bias | `model.fusion.reliability_bias=false` |
| Forecast before restore | `model.order=forecast_first` |
| Without channel curriculum | `channel.curriculum.enabled=false` |
