"""Degradation profiles: single-axis sweeps over latency, loss and bandwidth, and the joint
latency x loss grid with its robustness summaries (R-AUDC and GDI).

python tools/sweep.py --config configs/opv2v_camera.yaml --ckpt outputs/opv2v_camera/distilled.pth --sweeps joint
"""

import argparse
import json
import os

import numpy as np
import torch

from _common import channel_from_cfg

from charm.channel import UNCONSTRAINED
from charm.data import build_dataset
from charm.eval import evaluate_over_seeds, graceful_degradation_index, robustness_area
from charm.models import build_model
from charm.utils import load_config
from charm.utils.misc import load_checkpoint


def evaluate_point(model, dataset, device, params, seeds, metric, cfg):
    summary = evaluate_over_seeds(
        model, dataset, device, "realistic", params=params, seeds=seeds,
        batch_size=int(cfg.get("eval", {}).get("batch_size", 1)), num_workers=int(cfg["train"].get("num_workers", 4)),
    )
    return summary[metric]["mean"], summary[metric]["std"], summary["comm_log2_bytes"]["mean"]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    parser.add_argument("--ckpt", required=True)
    parser.add_argument("--sweeps", nargs="+", default=["latency", "loss", "bandwidth", "joint"])
    parser.add_argument("--seeds", type=int, default=5)
    parser.add_argument("--metric", default="AP@0.7")
    parser.add_argument("--out", default=None)
    parser.add_argument("--opts", nargs="*", default=[])
    args = parser.parse_args()

    cfg = load_config(args.config, args.opts)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = build_model(cfg).to(device)
    load_checkpoint(args.ckpt, model)
    dataset = build_dataset(cfg, cfg["dataset"].get("val_split", "test"), train=False)
    seeds = list(range(args.seeds))
    base = channel_from_cfg(cfg)
    sw = cfg.get("sweep", {})
    latencies = sw.get("latencies_ms", [0, 100, 200, 300, 400, 500])
    losses = sw.get("loss_rates", [0.0, 0.1, 0.2, 0.3, 0.4, 0.5])
    budgets = sw.get("log2_budgets", [10, 12, 14, 16, 18, 20])
    results = {}

    def run(params):
        return evaluate_point(model, dataset, device, params, seeds, args.metric, cfg)

    if "latency" in args.sweeps:
        results["latency"] = []
        for lat in latencies:
            p = base.with_mean_delay(lat).with_mean_loss(0.0).with_budget(UNCONSTRAINED)
            mean, std, comm = run(p)
            results["latency"].append({"latency_ms": lat, "mean": mean, "std": std, "comm": comm})
            print(f"latency {lat} ms: {mean:.2f} +- {std:.2f}")

    if "loss" in args.sweeps:
        results["loss"] = []
        for rho in losses:
            p = base.with_mean_delay(sw.get("fixed_latency_ms", 200)).with_mean_loss(rho).with_budget(UNCONSTRAINED)
            mean, std, comm = run(p)
            results["loss"].append({"loss_rate": rho, "mean": mean, "std": std, "comm": comm})
            print(f"loss {rho:.2f}: {mean:.2f} +- {std:.2f}")

    if "bandwidth" in args.sweeps:
        results["bandwidth"] = []
        for lb in budgets:
            p = base.with_mean_delay(sw.get("fixed_latency_ms", 200)).with_mean_loss(sw.get("fixed_loss", 0.2)).with_budget(2.0 ** lb)
            mean, std, comm = run(p)
            results["bandwidth"].append({"log2_budget": lb, "mean": mean, "std": std, "comm": comm})
            print(f"budget 2^{lb}: {mean:.2f} +- {std:.2f} (sent 2^{comm:.2f})")

    if "joint" in args.sweeps:
        grid = np.zeros((len(latencies), len(losses)))
        for i, lat in enumerate(latencies):
            for j, rho in enumerate(losses):
                p = base.with_mean_delay(lat).with_mean_loss(rho)
                grid[i, j] = run(p)[0]
                print(f"joint ({lat} ms, {rho:.2f}): {grid[i, j]:.2f}")
        taus = np.asarray(latencies, dtype=np.float64) / 1000.0
        results["joint"] = {
            "latencies_ms": latencies,
            "loss_rates": losses,
            "ap": grid.tolist(),
            "R-AUDC": robustness_area(grid, taus, losses),
            "GDI": graceful_degradation_index(grid),
        }
        print(f"R-AUDC={results['joint']['R-AUDC']:.3f} GDI={results['joint']['GDI']:.3f}")

    out = args.out or os.path.join(os.path.dirname(args.ckpt), "sweep.json")
    with open(out, "w") as f:
        json.dump(results, f, indent=2)
    print(f"saved {out}")


if __name__ == "__main__":
    main()
