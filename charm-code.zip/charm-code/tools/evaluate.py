"""Evaluate a checkpoint under the ideal and/or realistic channel (mean and std over channel seeds).

python tools/evaluate.py --config configs/opv2v_camera.yaml --ckpt outputs/opv2v_camera/distilled.pth
"""

import argparse
import json
import os

import torch

from _common import channel_from_cfg

from charm.data import build_dataset
from charm.eval import evaluate_over_seeds
from charm.models import build_model
from charm.utils import load_config
from charm.utils.misc import load_checkpoint


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    parser.add_argument("--ckpt", required=True)
    parser.add_argument("--channels", nargs="+", default=["ideal", "realistic"], choices=["ideal", "realistic"])
    parser.add_argument("--seeds", type=int, default=None)
    parser.add_argument("--mean-delay-ms", type=float, default=None)
    parser.add_argument("--loss-rate", type=float, default=None)
    parser.add_argument("--log2-budget", type=float, default=None)
    parser.add_argument("--out", default=None)
    parser.add_argument("--opts", nargs="*", default=[])
    args = parser.parse_args()

    cfg = load_config(args.config, args.opts)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = build_model(cfg).to(device)
    load_checkpoint(args.ckpt, model)
    dataset = build_dataset(cfg, cfg["dataset"].get("val_split", "test"), train=False)
    ecfg = cfg.get("eval", {})
    n_seeds = args.seeds or int(ecfg.get("num_channel_seeds", 5))

    params = channel_from_cfg(cfg)
    if args.mean_delay_ms is not None:
        params = params.with_mean_delay(args.mean_delay_ms)
    if args.loss_rate is not None:
        params = params.with_mean_loss(args.loss_rate)
    if args.log2_budget is not None:
        params = params.with_budget(2.0 ** args.log2_budget)

    results = {}
    for mode in args.channels:
        summary = evaluate_over_seeds(
            model, dataset, device, mode, params=params if mode == "realistic" else None,
            seeds=list(range(n_seeds)), batch_size=int(ecfg.get("batch_size", 1)),
            num_workers=int(cfg["train"].get("num_workers", 4)),
            iou_thresholds=tuple(ecfg.get("iou_thresholds", [0.5, 0.7])), progress=True,
        )
        results[mode] = summary
        line = " ".join(f"{k}={v['mean']:.2f}+-{v['std']:.2f}" for k, v in summary.items())
        print(f"[{mode}] {line}")

    out = args.out or os.path.join(os.path.dirname(args.ckpt), "eval.json")
    with open(out, "w") as f:
        json.dump(results, f, indent=2)
    print(f"saved {out}")


if __name__ == "__main__":
    main()
