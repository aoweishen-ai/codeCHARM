"""Parameter count and per-frame latency with a batch of one and two collaborators."""

import argparse
import time

import torch
from torch.utils.data import DataLoader

import _common  # noqa: F401

from charm.data import build_dataset, cooperative_collate
from charm.models import build_model
from charm.utils import load_config
from charm.utils.misc import load_checkpoint, move_to_device


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    parser.add_argument("--ckpt", default=None)
    parser.add_argument("--iters", type=int, default=50)
    parser.add_argument("--warmup", type=int, default=10)
    parser.add_argument("--opts", nargs="*", default=[])
    args = parser.parse_args()

    cfg = load_config(args.config, ["dataset.max_collaborators=2"] + args.opts)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = build_model(cfg).to(device).eval()
    if args.ckpt:
        load_checkpoint(args.ckpt, model)
    total = sum(p.numel() for p in model.parameters())
    student = sum(p.numel() for p in getattr(model.restorer, "student", torch.nn.Module()).parameters())
    print(f"parameters: {(total - student) / 1e6:.1f} M (excluding the {student / 1e6:.1f} M distillation copy)")

    dataset = build_dataset(cfg, cfg["dataset"].get("val_split", "test"), train=False)
    loader = DataLoader(dataset, batch_size=1, shuffle=False, num_workers=2, collate_fn=cooperative_collate)
    batch = move_to_device(next(iter(loader)), device)
    times = []
    with torch.no_grad():
        for i in range(args.warmup + args.iters):
            if device.type == "cuda":
                torch.cuda.synchronize()
            tic = time.perf_counter()
            model(batch, return_loss=False)
            if device.type == "cuda":
                torch.cuda.synchronize()
            if i >= args.warmup:
                times.append(time.perf_counter() - tic)
    print(f"latency: {1000 * sum(times) / len(times):.1f} ms per frame "
          f"(note: re-encodes the whole history buffer; the streaming receiver encodes only new frames)")


if __name__ == "__main__":
    main()
