"""Joint training of CHARM under domain-randomised channels with a channel curriculum.

Single GPU:   python tools/train.py --config configs/opv2v_camera.yaml
Multi GPU:    torchrun --nproc_per_node=8 tools/train.py --config configs/opv2v_camera.yaml
"""

import argparse
import math
import os
import time

import torch
from torch.nn.parallel import DistributedDataParallel
from torch.utils.data import DataLoader, DistributedSampler

from _common import curriculum_state

from charm.data import build_dataset, cooperative_collate
from charm.models import build_model
from charm.utils import load_config
from charm.utils.misc import (
    AverageMeter, get_logger, init_distributed, is_main_process, load_checkpoint,
    move_to_device, reduce_mean, save_checkpoint, seed_everything, unwrap,
)


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    parser.add_argument("--resume", default=None)
    parser.add_argument("--opts", nargs="*", default=[], help="dotted overrides, e.g. train.epochs=40")
    return parser.parse_args()


def build_optimizer(model, cfg):
    tcfg = cfg["train"]
    decay, no_decay = [], []
    for name, p in unwrap(model).named_parameters():
        if not p.requires_grad:
            continue
        (no_decay if p.ndim <= 1 or name.endswith(".bias") else decay).append(p)
    return torch.optim.AdamW(
        [{"params": decay, "weight_decay": float(tcfg.get("weight_decay", 1e-2))},
         {"params": no_decay, "weight_decay": 0.0}],
        lr=float(tcfg.get("lr", 2e-4)),
    )


def cosine_schedule(optimizer, total_steps, warmup_steps=500, min_ratio=1e-3):
    def factor(step):
        if step < warmup_steps:
            return (step + 1) / warmup_steps
        progress = (step - warmup_steps) / max(1, total_steps - warmup_steps)
        return min_ratio + (1 - min_ratio) * 0.5 * (1 + math.cos(math.pi * min(progress, 1.0)))

    return torch.optim.lr_scheduler.LambdaLR(optimizer, factor)


def main():
    args = parse_args()
    cfg = load_config(args.config, args.opts)
    rank, world, local = init_distributed()
    device = torch.device("cuda", local) if torch.cuda.is_available() else torch.device("cpu")
    tcfg = cfg["train"]
    out_dir = tcfg.get("out_dir", os.path.join("outputs", cfg.get("experiment", "charm")))
    logger = get_logger("charm", out_dir)
    seed_everything(int(tcfg.get("seed", 0)) + rank)

    dataset = build_dataset(cfg, cfg["dataset"].get("train_split", "train"), train=True)
    sampler = DistributedSampler(dataset, shuffle=True) if world > 1 else None
    loader_kwargs = dict(
        batch_size=int(tcfg.get("batch_size", 1)), num_workers=int(tcfg.get("num_workers", 4)),
        collate_fn=cooperative_collate, pin_memory=True, drop_last=True,
        persistent_workers=False,  # workers are re-created each epoch so curriculum changes propagate
    )

    model = build_model(cfg).to(device)
    if hasattr(model.restorer, "student"):
        model.restorer.student.requires_grad_(False)
    optimizer = build_optimizer(model, cfg)
    epochs = int(tcfg.get("epochs", 60))
    steps_per_epoch = math.ceil(len(dataset) / (loader_kwargs["batch_size"] * world))
    scheduler = cosine_schedule(optimizer, epochs * steps_per_epoch, int(tcfg.get("warmup_steps", 500)))

    start_epoch = 0
    if args.resume:
        epoch, _, _ = load_checkpoint(args.resume, model, optimizer, scheduler)
        start_epoch = (epoch or -1) + 1
        logger.info(f"resumed from {args.resume} at epoch {start_epoch}")
    if world > 1:
        model = DistributedDataParallel(model, device_ids=[local], find_unused_parameters=True)

    amp = bool(tcfg.get("amp", True)) and device.type == "cuda"
    clip = float(tcfg.get("grad_clip", 35.0))
    log_every = int(tcfg.get("log_interval", 50))
    meter = AverageMeter()

    for epoch in range(start_epoch, epochs):
        scale, tail = curriculum_state(epoch, cfg)
        dataset.set_epoch(epoch, scale, tail)
        if sampler is not None:
            sampler.set_epoch(epoch)
        loader = DataLoader(dataset, sampler=sampler, shuffle=sampler is None, **loader_kwargs)
        model.train()
        meter.reset()
        tic = time.time()
        for it, batch in enumerate(loader):
            batch = move_to_device(batch, device)
            with torch.autocast(device_type=device.type, dtype=torch.bfloat16, enabled=amp):
                out = model(batch, return_loss=True)
            loss = out["loss"]
            optimizer.zero_grad(set_to_none=True)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), clip)
            optimizer.step()
            scheduler.step()
            logs = {"loss": reduce_mean(loss.detach()).item()}
            logs.update({k: reduce_mean(v).item() for k, v in out["losses"].items()})
            meter.update(logs)
            if is_main_process() and (it + 1) % log_every == 0:
                logger.info(
                    f"epoch {epoch} iter {it + 1}/{len(loader)} channel_scale={scale:.2f} "
                    f"lr={scheduler.get_last_lr()[0]:.2e} {meter} ({time.time() - tic:.1f}s)"
                )
        logger.info(f"epoch {epoch} done: {meter}")
        save_checkpoint(os.path.join(out_dir, "latest.pth"), model, optimizer, scheduler, epoch)
        if (epoch + 1) % int(tcfg.get("save_every", 5)) == 0 or epoch + 1 == epochs:
            save_checkpoint(os.path.join(out_dir, f"epoch_{epoch:03d}.pth"), model, epoch=epoch)


if __name__ == "__main__":
    main()
