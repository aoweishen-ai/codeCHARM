"""Shared helpers for the command line tools."""

import os
import sys

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from charm.channel import ChannelParams  # noqa: E402


def channel_from_cfg(cfg):
    return ChannelParams.from_dict(cfg.get("channel", {}).get("nominal", {}))


def curriculum_state(epoch, cfg):
    """(scale, tail) for a given epoch: ideal channel, then a linear ramp, then the full range."""
    cur = cfg.get("channel", {}).get("curriculum", {})
    if not cur.get("enabled", True):
        return 1.0, True
    ideal = int(cur.get("ideal_epochs", 15))
    ramp = int(cur.get("ramp_epochs", 15))
    if epoch < ideal:
        return 0.0, False
    if epoch < ideal + ramp:
        return (epoch - ideal + 1) / float(max(ramp, 1)), False
    return 1.0, True
