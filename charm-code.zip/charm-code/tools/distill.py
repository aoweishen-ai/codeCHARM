"""Consistency distillation of the diffusion inpainter into a two-step student.

The trained pipeline is frozen; inpainting tasks (received latent, loss mask, ego latent, channel
embedding) are generated on the fly through the simulated channel.

python tools/distill.py --config configs/opv2v_camera.yaml --ckpt outputs/opv2v_camera/latest.pth
"""

import argparse
import os

import torch
from torch.utils.data import DataLoader

from _common import curriculum_state

from charm.data import build_dataset, cooperative_collate
from charm.models import build_model
from charm.models.diffusion import ConsistencyDistiller
from charm.utils import load_config
from charm.utils.misc import AverageMeter, get_logger, load_checkpoint, move_to_device, save_checkpoint, seed_everything


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    parser.add_argument("--ckpt", required=True)
    parser.add_argument("--out", default=None)
    parser.add_argument("--opts", nargs="*", default=[])
    args = parser.parse_args()

    cfg = load_config(args.config, args.opts)
    dcfg = cfg.get("distill", {})
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    out_dir = cfg["train"].get("out_dir", os.path.join("outputs", cfg.get("experiment", "charm")))
    logger = get_logger("charm.distill", out_dir)
    seed_everything(int(cfg["train"].get("seed", 0)))

    model = build_model(cfg).to(device)
    load_checkpoint(args.ckpt, model)
    if cfg["model"]["restorer"].get("type", "diffusion") != "diffusion":
        raise ValueError("distillation applies to the diffusion restorer only")
    model.eval()
    model.requires_grad_(False)
    distiller = ConsistencyDistiller(
        model.restorer,
        num_intervals=int(dcfg.get("num_intervals", 40)),
        ema_decay=float(dcfg.get("ema_decay", 0.999)),
        huber_c=float(dcfg.get("huber_c", 0.03)),
    )
    model.restorer.student.train()
    optimizer = torch.optim.AdamW(distiller.parameters(), lr=float(dcfg.get("lr", 1e-4)), weight_decay=0.0)

    dataset = build_dataset(cfg, cfg["dataset"].get("train_split", "train"), train=True)
    dataset.load_targets = False
    dataset.depth_supervision = False
    epochs = int(dcfg.get("epochs", 10))
    meter = AverageMeter()
    for epoch in range(epochs):
        dataset.set_epoch(epoch, *curriculum_state(10 ** 6, cfg))
        loader = DataLoader(
            dataset, batch_size=int(cfg["train"].get("batch_size", 1)), shuffle=True,
            num_workers=int(cfg["train"].get("num_workers", 4)), collate_fn=cooperative_collate, drop_last=True,
        )
        meter.reset()
        for it, batch in enumerate(loader):
            batch = move_to_device(batch, device)
            task = model.restoration_samples(batch)
            if task["u0"].shape[0] == 0:
                continue
            loss = distiller.loss(task["u0"], task["u_known"], task["mask"], task["region"], task["u_ego"], task["z_c"])
            optimizer.zero_grad(set_to_none=True)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(distiller.parameters(), 1.0)
            optimizer.step()
            distiller.update_ema()
            meter.update({"cd": loss.item()})
            if (it + 1) % int(cfg["train"].get("log_interval", 50)) == 0:
                logger.info(f"distill epoch {epoch} iter {it + 1}/{len(loader)} {meter}")
        logger.info(f"distill epoch {epoch} done: {meter}")

    distiller.finalize()
    out = args.out or os.path.join(out_dir, "distilled.pth")
    save_checkpoint(out, model, epoch=epochs)
    logger.info(f"saved distilled checkpoint to {out}")


if __name__ == "__main__":
    main()
