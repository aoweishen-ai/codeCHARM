# CHARM

Code for **CHARM: Channel-Adaptive Camera-V2X BEV Perception with Latency Compensation and Generative Feature Inpainting**.

CHARM is a camera-centric cooperative bird's-eye-view (BEV) detector that treats transmission
delay, bursty packet loss and bandwidth limits as one jointly estimated channel state:

* **Channel state embedding** – delay, loss rate, SNR and byte budget estimated at the receiver
  (timestamps, sequence numbers, PHY indicator, scheduler), expanded with random Fourier features
  and injected into every module by feature-wise affine modulation.
* **Knapsack gate** (sender) – a value head scores every 8x8 token group at 2/4/8-bit precision;
  a Lagrangian relaxation with bisection on the multiplier selects groups and bit depths under
  the per-link budget, with a straight-through hard decision and a hinge bandwidth penalty.
* **Conditional latent diffusion inpainter** (receiver) – lost token groups are restored in the
  16-channel message latent, conditioned on the loss mask, the aligned ego latent and the channel
  embedding, with known-region replacement at every reverse step. A consistency-distilled
  student needs two function evaluations; two stochastic samples give a per-token dispersion.
* **Selective state space predictor** – a per-collaborator buffer of K=4 irregularly timed
  latents is scanned with a selective SSM whose discretisation step is a learned gain times the
  physical timestamp gap; a zero-input step of length equal to the residual horizon rolls the
  state to the ego clock. Temporal scans alternate with bidirectional row/column spatial scans,
  followed by a dense displacement warp with a per-cell validity score.
* **Reliability-biased fusion** – a calibrated per-token reliability enters cross-agent
  attention as `beta * log r`; the ego is always present with reliability one, so fusion falls
  back to ego-only perception when every link becomes unreliable.

## Repository layout

```
charm/
  channel/     shifted-Gamma delay, Gilbert-Elliott burst loss, budget and pose noise,
               receiver-side estimation, channel embedding, packet-level loss simulation
  models/      image/LiDAR encoders, latent codec, message builder (knapsack gate),
               diffusion inpainter + consistency distillation, SSM predictor (and GRU /
               attention / flow alternatives), reliability head, fusion, detection head,
               full CHARM model
  data/        OPV2V / V2XSet / V2V4Real loader (OpenCOOD layout), DAIR-V2X-C /
               V2X-Seq-SPD loader, collation
  eval/        BEV AP@0.5/0.7, R-AUDC, GDI, communication volume, multi-seed evaluation
  runtime/     streaming sender / receiver with persistent buffers and link monitors
configs/       base config, one config per benchmark, ablation overrides
tools/         train, distill, evaluate, sweep, efficiency
```

## Installation

```
pip install -r requirements.txt
pip install mamba-ssm          # recommended on GPU, see "Memory" below
pip install -e .
```

## Data

Point `dataset.root` in each config to the downloaded benchmark.

| Benchmark            | Config                              | Expected layout                                                                                      |
| -------------------- | ----------------------------------- | ---------------------------------------------------------------------------------------------------- |
| OPV2V (camera)       | `configs/opv2v_camera.yaml`       | `<root>/{train,validate,test}/<scenario>/<cav_id>/<ts>.yaml, <ts>_camera{0..3}.png, <ts>.pcd`      |
| V2XSet (camera)      | `configs/v2xset_camera.yaml`      | same as OPV2V; infrastructure agents use negative ids                                                |
| DAIR-V2X-C (camera)  | `configs/dair_v2x_c_camera.yaml`  | `cooperative/`, `vehicle-side/`, `infrastructure-side/` with `data_info.json` and `calib/` |
| V2X-Seq-SPD (camera) | `configs/v2x_seq_spd_camera.yaml` | same as DAIR-V2X-C, with`sequence_id` fields                                                       |
| V2V4Real (LiDAR)     | `configs/v2v4real_lidar.yaml`     | OpenCOOD layout                                                                                      |

LiDAR point clouds are used only to supervise the depth distribution during camera training.

## Pipeline

1. **Joint training** with domain randomisation over the channel and the curriculum
   (15 ideal epochs, 15 ramp epochs, then the full range including the tail):

   ```
   torchrun --nproc_per_node=8 tools/train.py --config configs/opv2v_camera.yaml
   ```
2. **Consistency distillation** of the inpainter (8-step DDIM teacher to a 2-step student):

   ```
   python tools/distill.py --config configs/opv2v_camera.yaml --ckpt outputs/opv2v_camera/latest.pth
   ```
3. **Evaluation** under ideal and realistic channels (realistic numbers are the mean and standard
   deviation over five channel seeds with a fixed checkpoint and data order):

   ```
   python tools/evaluate.py --config configs/opv2v_camera.yaml --ckpt outputs/opv2v_camera/distilled.pth
   ```
4. **Degradation profiles** (latency / loss / bandwidth sweeps and the joint grid with R-AUDC and GDI):

   ```
   python tools/sweep.py --config configs/opv2v_camera.yaml --ckpt outputs/opv2v_camera/distilled.pth
   ```
5. **Efficiency** (parameters and per-frame latency with two collaborators):

   ```
   python tools/efficiency.py --config configs/opv2v_camera.yaml --ckpt outputs/opv2v_camera/distilled.pth
   ```

Any config key can be overridden from the command line, e.g. `--opts train.epochs=40 model.predictor.type=gru`.
Ablation overrides are listed in `configs/ablations/README.md`.

## Channel protocol

The realistic channel uses `tau = 50 ms + Gamma(k=2, theta=75 ms)`, a Gilbert-Elliott chain with
`p_GB=0.08, p_BG=0.35, eps_G=0.01, eps_B=0.6`, a budget of 2^16 bytes per link per frame and pose
noise of 0.2 m / 0.2 deg. Each token group is one packet; packets are transmitted in Morton order,
so bursts become spatially contiguous holes on the BEV plane.

Note that the four Gilbert-Elliott parameters above give a stationary loss rate of about 0.12,
not 0.20. The config therefore exposes `channel.nominal.target_mean_loss` (default 0.20), which
re-calibrates `p_GB` while keeping the other three parameters; set it to `null` to use the raw
parameters instead.

## Implementation notes

* **Training-time history.** For batched training the K buffered collaborator frames are
  re-encoded from sensor data for every sample, and all buffered messages are restored with the
  current ego latent as condition. `charm/runtime/online.py` implements the streaming form in
  which only newly arrived messages are restored, buffers persist across frames and are
  re-aligned to the current ego pose.
* **Rigid alignment** of received latents into the ego frame is performed on the receive side
  using the pose carried by each token group, since the sender cannot know the ego pose at fusion time.
* **Gradient flow through restoration.** The sampler runs without gradients; restored latents
  are recomposed as `M * received + (1 - M) * generated`, so detection gradients still reach the
  transmitted tokens and the value head. The inpainter is trained by the masked denoising loss;
  the task-consistency term is applied to the one-step clean estimate of the denoising pass,
  weighted by the signal level of the sampled timestep.
* **Unsent token groups** (deliberately skipped by the gate) are excluded from fusion;
  lost groups are restored and enter fusion with their reliability.
* **Reliability calibration target** is `clamp(1 - ||F_hat - F_sync|| / ||F_sync||, 0, 1)`,
  where `F_sync` is the collaborator feature synchronised to the ego timestamp.
* **Latent codec** is trained with an additional reconstruction loss (`loss.rec`).
* **Memory.** The temporal recurrence materialises a `(d_inner x d_state)` state per BEV
  location. The bidirectional spatial scans use the fused `mamba-ssm` kernel when installed and a
  parallel log-space reference scan otherwise; the reference scan is exact but memory-hungry, so
  without `mamba-ssm` set `model.predictor.spatial_stride=2` for training. Gradient checkpointing
  of the predictor blocks is on by default.
* **Not included:** re-implementations of the thirteen baselines and the adversarial-inpainter
  ablation; every other ablation in the paper maps to a config switch.
