from setuptools import find_packages, setup

setup(
    name="charm",
    version="0.1.0",
    description="Channel-adaptive camera V2X BEV perception with latency compensation and generative feature inpainting",
    packages=find_packages(exclude=("tools", "configs")),
    python_requires=">=3.9",
    install_requires=[
        "torch>=2.1",
        "torchvision>=0.16",
        "numpy>=1.23",
        "pyyaml>=6.0",
        "pillow>=9.0",
        "shapely>=2.0",
        "tqdm>=4.64",
    ],
)
